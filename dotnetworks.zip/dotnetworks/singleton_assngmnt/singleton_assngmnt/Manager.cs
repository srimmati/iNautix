﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace singleton_assngmnt
{
    class Manager
    {
        string ManagerName;
        int ManagerID;
        public string PManagerName
        {
            get
            {
                return ManagerName;
            }
        }
        public int PManagerID
        {
            get
            {
                return ManagerID;

            }
        }
        private Manager(string ManagerName, int ManagerID)
        {
            this.ManagerName = ManagerName;
            this.ManagerID = ManagerID;

        }
        static Manager m;
        public static Manager GetManager()
        {
            if (m == null)
            {
                m = new Manager("ABC", 1000);
            }
            return m;
        }

    }
}
