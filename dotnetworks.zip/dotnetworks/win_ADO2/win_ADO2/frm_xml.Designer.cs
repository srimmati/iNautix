﻿namespace win_ADO2
{
    partial class frm_xml
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_savexml = new System.Windows.Forms.Button();
            this.btn_readxml = new System.Windows.Forms.Button();
            this.dg_orders = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_orders)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_savexml
            // 
            this.btn_savexml.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_savexml.Location = new System.Drawing.Point(48, 37);
            this.btn_savexml.Name = "btn_savexml";
            this.btn_savexml.Size = new System.Drawing.Size(107, 41);
            this.btn_savexml.TabIndex = 0;
            this.btn_savexml.Text = "Save XML";
            this.btn_savexml.UseVisualStyleBackColor = true;
            this.btn_savexml.Click += new System.EventHandler(this.btn_savexml_Click);
            // 
            // btn_readxml
            // 
            this.btn_readxml.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_readxml.Location = new System.Drawing.Point(199, 37);
            this.btn_readxml.Name = "btn_readxml";
            this.btn_readxml.Size = new System.Drawing.Size(107, 41);
            this.btn_readxml.TabIndex = 1;
            this.btn_readxml.Text = "Read XML";
            this.btn_readxml.UseVisualStyleBackColor = true;
            this.btn_readxml.Click += new System.EventHandler(this.btn_readxml_Click);
            // 
            // dg_orders
            // 
            this.dg_orders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_orders.Location = new System.Drawing.Point(48, 94);
            this.dg_orders.Name = "dg_orders";
            this.dg_orders.Size = new System.Drawing.Size(240, 150);
            this.dg_orders.TabIndex = 2;
            // 
            // frm_xml
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 282);
            this.Controls.Add(this.dg_orders);
            this.Controls.Add(this.btn_readxml);
            this.Controls.Add(this.btn_savexml);
            this.Name = "frm_xml";
            this.Text = "frm_xml";
            ((System.ComponentModel.ISupportInitialize)(this.dg_orders)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_savexml;
        private System.Windows.Forms.Button btn_readxml;
        private System.Windows.Forms.DataGridView dg_orders;
    }
}