﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace win_ADO2
{
    public partial class frm_xml : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public frm_xml()
        {
            InitializeComponent();
        }

        private void btn_savexml_Click(object sender, EventArgs e)
        {
         
            SqlDataAdapter adapter_orders = new SqlDataAdapter("select * from OrderDetails", con);
            DataSet ds = new DataSet();
            adapter_orders.Fill(ds, "orddetails");
            ds.WriteXml("C:/Users/XBBNHGQ/test/orddetails.xml");
            MessageBox.Show("XML file generated");
        }

        private void btn_readxml_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            ds.ReadXml("C:/Users/XBBNHGQ/test/ords.xml");
            ds.ReadXml("C:/Users/XBBNHGQ/test/orddetails.xml");
            dg_orders.DataSource = ds.Tables["orddetails"];
              
        }
    }
}
