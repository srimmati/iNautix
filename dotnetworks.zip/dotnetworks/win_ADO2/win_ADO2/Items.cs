﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace win_ADO2
{
    class Items
    {
        public int OrderId { get; set; }
        public int ItemId { get; set; }
        public int ItemQty { get; set; }
        public int ItemPrice { get; set; }
    }
}



