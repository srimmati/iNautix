﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace win_ADO2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_placeorder_Click(object sender, EventArgs e)
        {
            try
            {
                Order ord = new Order();
                ord.CustomerName = txt_custname.Text;
                Items item = new Items();
                item.ItemId = Convert.ToInt32(txt_itemid.Text);
                item.ItemPrice = Convert.ToInt32(txt_itemprice.Text);
                item.ItemQty = Convert.ToInt32(txt_itemqty.Text);

                ord.AddItem(item);

                OrdersDAL dal = new OrdersDAL();
                dal.AddOrder(ord);
                txt_orderid.Text = ord.OrderId.ToString();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
    }
}
