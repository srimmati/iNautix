﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace win_ADO2
{
    class Order
    {
        public int OrderId { get; set; }
        public string CustomerName { get; set; }
        public DateTime Orderdate { get; set; }

        public List<Items> items = new List<Items>();
        public void AddItem(Items item)
        {
            items.Add(item);

        }
    }
}
