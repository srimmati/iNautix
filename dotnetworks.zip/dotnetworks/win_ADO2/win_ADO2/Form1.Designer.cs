﻿namespace win_ADO2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.lbl_custname = new System.Windows.Forms.Label();
            this.bl_itemid = new System.Windows.Forms.Label();
            this.lbl_itemqty = new System.Windows.Forms.Label();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.txt_orderid = new System.Windows.Forms.TextBox();
            this.txt_custname = new System.Windows.Forms.TextBox();
            this.txt_itemqty = new System.Windows.Forms.TextBox();
            this.txt_itemid = new System.Windows.Forms.TextBox();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_orderid.Location = new System.Drawing.Point(65, 34);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(93, 28);
            this.lbl_orderid.TabIndex = 0;
            this.lbl_orderid.Text = "Order Id :";
            // 
            // lbl_custname
            // 
            this.lbl_custname.AutoSize = true;
            this.lbl_custname.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custname.Location = new System.Drawing.Point(64, 91);
            this.lbl_custname.Name = "lbl_custname";
            this.lbl_custname.Size = new System.Drawing.Size(151, 28);
            this.lbl_custname.TabIndex = 0;
            this.lbl_custname.Text = "Customer Name :";
            // 
            // bl_itemid
            // 
            this.bl_itemid.AutoSize = true;
            this.bl_itemid.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bl_itemid.Location = new System.Drawing.Point(65, 130);
            this.bl_itemid.Name = "bl_itemid";
            this.bl_itemid.Size = new System.Drawing.Size(81, 28);
            this.bl_itemid.TabIndex = 0;
            this.bl_itemid.Text = "Item Id :";
            // 
            // lbl_itemqty
            // 
            this.lbl_itemqty.AutoSize = true;
            this.lbl_itemqty.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemqty.Location = new System.Drawing.Point(65, 178);
            this.lbl_itemqty.Name = "lbl_itemqty";
            this.lbl_itemqty.Size = new System.Drawing.Size(94, 28);
            this.lbl_itemqty.TabIndex = 0;
            this.lbl_itemqty.Text = "Item Qty :";
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemprice.Location = new System.Drawing.Point(64, 218);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(105, 28);
            this.lbl_itemprice.TabIndex = 0;
            this.lbl_itemprice.Text = "Item Price :";
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_placeorder.Location = new System.Drawing.Point(140, 290);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(128, 40);
            this.btn_placeorder.TabIndex = 1;
            this.btn_placeorder.Text = "Place Order";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // txt_orderid
            // 
            this.txt_orderid.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_orderid.Location = new System.Drawing.Point(287, 34);
            this.txt_orderid.Name = "txt_orderid";
            this.txt_orderid.Size = new System.Drawing.Size(151, 36);
            this.txt_orderid.TabIndex = 2;
            // 
            // txt_custname
            // 
            this.txt_custname.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_custname.Location = new System.Drawing.Point(287, 83);
            this.txt_custname.Name = "txt_custname";
            this.txt_custname.Size = new System.Drawing.Size(151, 36);
            this.txt_custname.TabIndex = 2;
            // 
            // txt_itemqty
            // 
            this.txt_itemqty.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemqty.Location = new System.Drawing.Point(287, 175);
            this.txt_itemqty.Name = "txt_itemqty";
            this.txt_itemqty.Size = new System.Drawing.Size(151, 36);
            this.txt_itemqty.TabIndex = 2;
            // 
            // txt_itemid
            // 
            this.txt_itemid.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemid.Location = new System.Drawing.Point(287, 122);
            this.txt_itemid.Name = "txt_itemid";
            this.txt_itemid.Size = new System.Drawing.Size(151, 36);
            this.txt_itemid.TabIndex = 2;
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemprice.Location = new System.Drawing.Point(287, 215);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(151, 36);
            this.txt_itemprice.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 365);
            this.Controls.Add(this.txt_itemid);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.txt_itemqty);
            this.Controls.Add(this.txt_custname);
            this.Controls.Add(this.txt_orderid);
            this.Controls.Add(this.btn_placeorder);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.lbl_itemqty);
            this.Controls.Add(this.bl_itemid);
            this.Controls.Add(this.lbl_custname);
            this.Controls.Add(this.lbl_orderid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Label lbl_custname;
        private System.Windows.Forms.Label bl_itemid;
        private System.Windows.Forms.Label lbl_itemqty;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.Button btn_placeorder;
        private System.Windows.Forms.TextBox txt_orderid;
        private System.Windows.Forms.TextBox txt_custname;
        private System.Windows.Forms.TextBox txt_itemqty;
        private System.Windows.Forms.TextBox txt_itemid;
        private System.Windows.Forms.TextBox txt_itemprice;
    }
}

