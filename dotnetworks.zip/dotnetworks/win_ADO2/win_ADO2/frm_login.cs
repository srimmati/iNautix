﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace win_ADO2
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.empid = Convert.ToInt32(txt_id.Text);
            obj.emppwd = txt_pwd.Text;
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.Login(obj);
            if (status)
            {
                MessageBox.Show("Valid User :" + obj.empname);

            }
            else
            {
                MessageBox.Show("Invalid User");
            }
        }
    }
}
