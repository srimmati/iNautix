﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace win_ADO2
{
    class Employee
    {
        public int empid { get; set; }
        public string empname { get; set; }
        public string emppwd { get; set; }
    }
}
