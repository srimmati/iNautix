﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace leaveApp_wpf
{
    /// <summary>
    /// Interaction logic for home.xaml
    /// </summary>
    public partial class home : Window
    {
        public home()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void btn_find_Click(object sender, RoutedEventArgs e)
        {
            employee obj=new employee();
            obj.employeeID=Convert.ToInt32(txt_fid.Text);
            employeeDal find = new employeeDal();
            bool status = find.findemployee(obj);
            if (status)
            {
                MessageBox.Show("Your Employye Id is " + obj.employeeID + "Name is  " + obj.employeeName);

            }
            else
            {
                MessageBox.Show("Employee not found");
            }
           

           
        }

        private void btn_req_Click(object sender, RoutedEventArgs e)
        {
            leavepage lg = new leavepage();
            lg.Show();

        }

        private void btn_shwreq_Click(object sender, RoutedEventArgs e)
        {
            leavereq obj = new leavereq();
            employeeDal dal = new employeeDal();
            obj.employeeid = Convert.ToInt32(txt_fid.Text);
               dg_req.ItemsSource = dal.ShowLeave(obj.employeeid);
        }

    }
}
