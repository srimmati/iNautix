﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace leaveApp_wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            employee emp = new employee();
            emp.employeeID =Convert.ToInt32( txt_id.Text);
            emp.employeePassword = txt_pass.Text;
            employeeDal log = new employeeDal();

            bool status = log.login(emp);
            if (status)
            {
                home home = new home();
                home.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid user");
            }

            
        }

        private void btn_signup_Click(object sender, RoutedEventArgs e)
        {
            employee emp_signup = new employee();
            emp_signup.employeeName = txt_name.Text;
            emp_signup.employeeExp = Convert.ToInt32(txt_exp.Text);
            emp_signup.employeeDept = txt_empdprtmnt.Text;
            emp_signup.employeeDesg = txt_empdesg.Text;
            emp_signup.employeePassword = txt_emppass.Text;
            emp_signup.managerid = Convert.ToInt32(txt_mangid.Text);

            employeeDal signup = new employeeDal();
            bool status = signup.addemployee(emp_signup);
            if (status)
            {
                MessageBox.Show("Employee added successfully");
            }


        }
    }
}
