﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace leaveApp_wpf
{
    /// <summary>
    /// Interaction logic for leavepage.xaml
    /// </summary>
    public partial class leavepage : Window
    {
        public leavepage()
        {
            InitializeComponent();
        }

        //private void Button_Click(object sender, RoutedEventArgs e)
        //{

        //}

        private void Request_Click(object sender, RoutedEventArgs e)
        {
           
           
            leavereq lev = new leavereq();
            lev.employeeid =Convert.ToInt32( txt_lempid.Text);
            lev.leavereqdate = txt_lreqdate.Text;
            lev.noofdays = Convert.ToInt32(txt_ldays.Text);
            lev.leavetype = txt_ltype.Text;
            lev.reason = txt_lreason.Text;
            lev.status = txt_lstatus.Text;
            employeeDal req = new employeeDal();
            bool status = req.leaverequest(lev);
            if (status)
            {

            }

        }
    }
}
