﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace leaveApp_wpf
{
    class employeeDal
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool login(employee emp)
        {
            con.Open();
            SqlCommand com_login = new SqlCommand("select count(*) from employeetable where employeeId=@empid and employeePassword=@emppass", con);
            com_login.Parameters.AddWithValue("@empid", emp.employeeID);
            com_login.Parameters.AddWithValue("@emppass", emp.employeePassword);
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public bool addemployee(employee add)
        {
            con.Open();
            SqlCommand com_add = new SqlCommand("insert employeetable values (@empname,@empexp,@emppass,@empdept,@empdesg,@managerid)", con);
            com_add.Parameters.AddWithValue("@empname", add.employeeName);
            com_add.Parameters.AddWithValue("@empexp",add.employeeExp);
            com_add.Parameters.AddWithValue("@emppass",add.employeePassword);
            com_add.Parameters.AddWithValue("@empdept",add.employeeDept);
            com_add.Parameters.AddWithValue("@empdesg",add.employeeDesg);
            com_add.Parameters.AddWithValue("@managerid",add.managerid);
            com_add.ExecuteNonQuery();
            con.Close();
            return true;
        }
        public bool findemployee(employee obj)
        {
            con.Open();
            SqlCommand find_emp = new SqlCommand("Select * from employeetable where employeeId=@empid", con);
            find_emp.Parameters.AddWithValue("@empid", obj.employeeID);
            SqlDataReader dr = find_emp.ExecuteReader();
            if (dr.Read())
            {

                obj.employeeName = dr.GetString(1);
                obj.employeeExp = dr.GetInt32(2);
                obj.employeeDept = dr.GetString(4);
                obj.employeeDesg = dr.GetString(5);
                obj.managerid = dr.GetInt32(6);

                SqlCommand com_id = new SqlCommand("select @@identity", con);
                con.Close();
               
                //int id = Convert.ToInt32(com_id.ExecuteScalar());
              //  obj.employeeID = id;
                return true;

            }
            else
            {
                return false;
            }
            
        }
        public bool leaverequest(leavereq lev)
        {
            con.Open();
            SqlCommand com_req = new SqlCommand("insert LeaveRequest values(@empid,@date,@noofdays,@leavtype,@reason,@status)", con);

            com_req.Parameters.AddWithValue("@empid", lev.employeeid);
            com_req.Parameters.AddWithValue("@date", lev.leavereqdate);
            com_req.Parameters.AddWithValue("@noofdays", lev.noofdays);
            com_req.Parameters.AddWithValue("@leavtype", lev.leavetype);
            com_req.Parameters.AddWithValue("@reason", lev.reason);
            com_req.Parameters.AddWithValue("@status",lev.status);
            com_req.ExecuteNonQuery();
            con.Close();
            return true;
        }

        public List<leavereq> ShowLeave(int EmployeeID)
        {
            List<leavereq> reqlist = new List<leavereq>();
            SqlCommand com_orders = new SqlCommand("select * from leaverequest where employeeId=@empid", con);
            com_orders.Parameters.AddWithValue("@empid", EmployeeID);

            con.Open();
           // SqlCommand com_lid = new SqlCommand("select @@identity",con);
          //  int lev_id = Convert.ToInt32(com_lid.ExecuteScalar());

            SqlDataReader dr = com_orders.ExecuteReader();
            while (dr.Read())
            {



                leavereq leave = new leavereq();
             //   leave.leaveid = lev_id;
                leave.leavereqdate = dr.GetString(2);
                leave.noofdays=dr.GetInt32(3);
                leave.leavetype = dr.GetString(4);
                leave.reason = dr.GetString(5);
                leave.status=dr.GetString(6);
              
            }

            con.Close();
            return reqlist;
        }

    }
}
