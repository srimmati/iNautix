﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace leaveApp_wpf
{
    class employee
    {
        public int employeeID { get; set; }
        public string employeeName { get; set; }
        public int employeeExp { get; set; }
        public string employeePassword { get; set; }
        public string employeeDept { get; set; }
        public string employeeDesg { get; set; }
        public int managerid { get; set; }

    }
}
