﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace leaveApp_wpf
{
    class leavereq
    {
        public int leaveid { get; set; }
        public int employeeid { get; set; }
        public string leavereqdate { get; set; }
        public int noofdays { get; set; }
        public string leavetype { get; set; }
        public string reason { get; set; }
        public string status { get; set; }
    }
}
