﻿namespace wcf_duplex_client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_cal = new System.Windows.Forms.Button();
            this.lst_data = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_cal
            // 
            this.btn_cal.Location = new System.Drawing.Point(76, 131);
            this.btn_cal.Name = "btn_cal";
            this.btn_cal.Size = new System.Drawing.Size(164, 88);
            this.btn_cal.TabIndex = 0;
            this.btn_cal.Text = "Call WCF";
            this.btn_cal.UseVisualStyleBackColor = true;
            this.btn_cal.Click += new System.EventHandler(this.btn_cal_Click);
            // 
            // lst_data
            // 
            this.lst_data.FormattingEnabled = true;
            this.lst_data.Location = new System.Drawing.Point(346, 124);
            this.lst_data.Name = "lst_data";
            this.lst_data.Size = new System.Drawing.Size(120, 95);
            this.lst_data.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 413);
            this.Controls.Add(this.lst_data);
            this.Controls.Add(this.btn_cal);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_cal;
        private System.Windows.Forms.ListBox lst_data;
    }
}

