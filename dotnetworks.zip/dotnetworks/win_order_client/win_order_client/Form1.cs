﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;

namespace win_order_client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");

        private void btn_add_Click(object sender, EventArgs e)
        {
            try
            {
                ServiceReference1.Orders obj = new ServiceReference1.Orders();
                obj.CustomerName = txt_custname.Text;
                obj.OrderAmt = Convert.ToInt32(txt_amt.Text);
                obj.CustomerCity = txt_custcity.Text;
                int oid = proxy.AddOrder(obj);
                MessageBox.Show("Order Added :" + oid);
                txt_custid.Text = oid.ToString();
            }
            catch (FaultException <ServiceReference1.ErrorInfo> exp)
            {
                MessageBox.Show(exp.Detail.ErrorNo+ " " + exp.Detail.ErrorDateTime+ "  "+exp.Detail.ErrorDetails);
            }
            

        }

        private void btn_get_Click(object sender, EventArgs e)
        {
            proxy.GetOrdersCompleted += new EventHandler<ServiceReference1.GetOrdersCompletedEventArgs>(proxy_GetOrdersCompleted);
            proxy.GetOrdersAsync(txt_search.Text);
        }

        void proxy_GetOrdersCompleted(object sender, ServiceReference1.GetOrdersCompletedEventArgs e)
        {
            dg_orders.DataSource = e.Result.ToList();
        }
    }
}
