﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ADO_Assignment2
{
    class Banktransaction
    {
       public int transid { get; set; }
        public  int accountno { get; set; }
       public int amount { get; set; }
       public   DateTime transdate { get; set; }

    }
}
