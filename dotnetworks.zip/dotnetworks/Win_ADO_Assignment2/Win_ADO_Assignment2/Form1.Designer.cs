﻿namespace Win_ADO_Assignment2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_accountno = new System.Windows.Forms.Label();
            this.lbl_amount = new System.Windows.Forms.Label();
            this.lbl_moviename = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.text_accno = new System.Windows.Forms.TextBox();
            this.text_amount = new System.Windows.Forms.TextBox();
            this.text_moviename = new System.Windows.Forms.TextBox();
            this.text_moviedate = new System.Windows.Forms.TextBox();
            this.text_timing = new System.Windows.Forms.TextBox();
            this.text_noticket = new System.Windows.Forms.TextBox();
            this.btn_book = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_accountno
            // 
            this.lbl_accountno.AutoSize = true;
            this.lbl_accountno.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accountno.Location = new System.Drawing.Point(57, 34);
            this.lbl_accountno.Name = "lbl_accountno";
            this.lbl_accountno.Size = new System.Drawing.Size(130, 26);
            this.lbl_accountno.TabIndex = 0;
            this.lbl_accountno.Text = "ACCOUNT NO :";
            // 
            // lbl_amount
            // 
            this.lbl_amount.AutoSize = true;
            this.lbl_amount.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_amount.Location = new System.Drawing.Point(57, 66);
            this.lbl_amount.Name = "lbl_amount";
            this.lbl_amount.Size = new System.Drawing.Size(94, 26);
            this.lbl_amount.TabIndex = 0;
            this.lbl_amount.Text = "AMOUNT :";
            // 
            // lbl_moviename
            // 
            this.lbl_moviename.AutoSize = true;
            this.lbl_moviename.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_moviename.Location = new System.Drawing.Point(57, 102);
            this.lbl_moviename.Name = "lbl_moviename";
            this.lbl_moviename.Size = new System.Drawing.Size(128, 26);
            this.lbl_moviename.TabIndex = 0;
            this.lbl_moviename.Text = "MOVIE NAME :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(57, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 26);
            this.label4.TabIndex = 0;
            this.label4.Text = "TIMING";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(57, 142);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 26);
            this.label5.TabIndex = 0;
            this.label5.Text = "MOVIE DATE :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(57, 200);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(149, 26);
            this.label6.TabIndex = 0;
            this.label6.Text = "NO. OF TICKETS :";
            // 
            // text_accno
            // 
            this.text_accno.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_accno.Location = new System.Drawing.Point(199, 34);
            this.text_accno.Name = "text_accno";
            this.text_accno.Size = new System.Drawing.Size(100, 34);
            this.text_accno.TabIndex = 1;
            // 
            // text_amount
            // 
            this.text_amount.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_amount.Location = new System.Drawing.Point(199, 59);
            this.text_amount.Name = "text_amount";
            this.text_amount.Size = new System.Drawing.Size(100, 34);
            this.text_amount.TabIndex = 1;
            // 
            // text_moviename
            // 
            this.text_moviename.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_moviename.Location = new System.Drawing.Point(199, 99);
            this.text_moviename.Name = "text_moviename";
            this.text_moviename.Size = new System.Drawing.Size(100, 34);
            this.text_moviename.TabIndex = 1;
            // 
            // text_moviedate
            // 
            this.text_moviedate.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_moviedate.Location = new System.Drawing.Point(199, 135);
            this.text_moviedate.Name = "text_moviedate";
            this.text_moviedate.Size = new System.Drawing.Size(100, 34);
            this.text_moviedate.TabIndex = 1;
            // 
            // text_timing
            // 
            this.text_timing.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_timing.Location = new System.Drawing.Point(199, 166);
            this.text_timing.Name = "text_timing";
            this.text_timing.Size = new System.Drawing.Size(100, 34);
            this.text_timing.TabIndex = 1;
            // 
            // text_noticket
            // 
            this.text_noticket.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_noticket.Location = new System.Drawing.Point(199, 193);
            this.text_noticket.Name = "text_noticket";
            this.text_noticket.Size = new System.Drawing.Size(100, 34);
            this.text_noticket.TabIndex = 1;
            // 
            // btn_book
            // 
            this.btn_book.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_book.Location = new System.Drawing.Point(169, 270);
            this.btn_book.Name = "btn_book";
            this.btn_book.Size = new System.Drawing.Size(130, 38);
            this.btn_book.TabIndex = 2;
            this.btn_book.Text = "BOOK TICKET";
            this.btn_book.UseVisualStyleBackColor = true;
            this.btn_book.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 383);
            this.Controls.Add(this.btn_book);
            this.Controls.Add(this.text_noticket);
            this.Controls.Add(this.text_timing);
            this.Controls.Add(this.text_moviedate);
            this.Controls.Add(this.text_moviename);
            this.Controls.Add(this.text_amount);
            this.Controls.Add(this.text_accno);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbl_moviename);
            this.Controls.Add(this.lbl_amount);
            this.Controls.Add(this.lbl_accountno);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_accountno;
        private System.Windows.Forms.Label lbl_amount;
        private System.Windows.Forms.Label lbl_moviename;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox text_accno;
        private System.Windows.Forms.TextBox text_amount;
        private System.Windows.Forms.TextBox text_moviename;
        private System.Windows.Forms.TextBox text_moviedate;
        private System.Windows.Forms.TextBox text_timing;
        private System.Windows.Forms.TextBox text_noticket;
        private System.Windows.Forms.Button btn_book;
    }
}

