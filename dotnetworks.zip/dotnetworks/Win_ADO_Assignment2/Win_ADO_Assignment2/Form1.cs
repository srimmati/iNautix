﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_ADO_Assignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Banktransaction bank = new Banktransaction();
            bank.accountno = Convert.ToInt32(text_accno.Text);
            bank.amount = Convert.ToInt32(text_amount.Text);
            Tickets tck = new Tickets();
            tck.moviename = text_moviename.Text;
            tck.moviedate = (text_moviedate.Text);
            tck.time=text_timing.Text;
            tck.nooftickets = Convert.ToInt32(text_noticket.Text);

            TicketDAL tdal = new TicketDAL();
            tdal.BuyTicket(bank, tck);
            MessageBox.Show("Your ticket no is" + tck.ticketno);
            MessageBox.Show("Your transcation id is" + bank.transid);

        }
    }
}
