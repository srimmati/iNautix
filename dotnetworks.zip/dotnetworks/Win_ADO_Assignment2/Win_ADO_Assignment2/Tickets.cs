﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ADO_Assignment2
{
    class Tickets
    {
        public int ticketno { get; set; }
        public string moviename { get; set; }
        public string moviedate { get; set; }
        public string time { get; set; }
        public int nooftickets { get; set; }
        public int transid { get; set; }
        public DateTime ticketdate { get; set; }

    }
}
