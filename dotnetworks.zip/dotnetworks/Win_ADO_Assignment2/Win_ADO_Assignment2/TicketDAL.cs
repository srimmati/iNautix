﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
namespace Win_ADO_Assignment2
{
    class TicketDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public void BuyTicket(Banktransaction bt, Tickets tc)
        {
            con.Open();
            SqlTransaction trans = con.BeginTransaction();
            SqlCommand com_bank = new SqlCommand("insert BankTransaction values(@accntno,@amt,getdate())", con);
            com_bank.Transaction = trans;
            com_bank.Parameters.AddWithValue("@accntno", bt.accountno);
            com_bank.Parameters.AddWithValue("@amt", bt.amount);
            com_bank.ExecuteNonQuery();
            SqlCommand com_tranid = new SqlCommand("select @@identity", con);
            com_tranid.Transaction = trans;
            int transactionid = Convert.ToInt32(com_tranid.ExecuteScalar());
            bt.transid = transactionid;

            SqlCommand com_ticket = new SqlCommand("insert ticketdetails values(@moviename,@moviedate,@movietime,@nooftickets,@transid,getdate())", con);
            com_ticket.Transaction = trans;
            com_ticket.Parameters.AddWithValue("@moviename", tc.moviename);
            com_ticket.Parameters.AddWithValue("@moviedate", tc.moviedate);
            com_ticket.Parameters.AddWithValue("@movietime", tc.time);
            com_ticket.Parameters.AddWithValue("@nooftickets", tc.nooftickets);
            com_ticket.Parameters.AddWithValue("@transid", transactionid);
            com_ticket.ExecuteNonQuery();


            SqlCommand com_ticketno = new SqlCommand("select @@identity", con);
            com_ticketno.Transaction = trans;
            int ticketno = Convert.ToInt32(com_ticketno.ExecuteScalar());
            tc.ticketno = ticketno;
            
            trans.Commit();
            con.Close();
        }


    }
}
