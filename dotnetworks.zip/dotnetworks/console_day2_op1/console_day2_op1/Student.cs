﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace console_day2_op1
{
    class Student
    {
        int StudentID;
        public int pstudentId
        {
            get
            {
                return StudentID;
            }
        }

        string StudentName;
        public string pstudentName
        {
            get
            {
                return StudentName;
            }
            set
            {
                StudentName = value;
            }
        }
        int StudentMArks;
        public int pstudentMarks
        {
            get
            {
                return StudentMArks;
            }
            set
            {
                if (value < 0 || value > 100)
                {
                    StudentMArks = 0;
                }
                else
                {
                    StudentMArks = value;
                    if (StudentMArks > 50)
                    {
                        StudentStatus = true;
                    }
                    else
                    {
                        StudentStatus=false;
                    }
                }
            }
        }

        
        bool StudentStatus;
        public bool Pstudentstatus
        {
            get
            {
                return StudentStatus;
            }

        }


        public Student(int StudentID, string StudentName)
        {
            this.StudentID = StudentID;
            this.StudentName = StudentName;

        }
        public Student(int StudentID)
        {
            this.StudentID = StudentID;
            this.StudentName = "ÄBCD";
            this.StudentMArks = 80;
        }
    }
}
