﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace console_day2_op1
{
    class Customer
    {

        public static int count;

        
        public void GEtdata(string str, int i = 100)
        {
            Console.WriteLine(str + "  " + i);

        }


         private int customerID;
         private string customerName;
         private string customerAddress;
         private int customerAge;

        public Customer()
         {
             Console.WriteLine("Constructor called without parameters");

         }
         public Customer(int customerId, string customerName, string customerAddress, int customerAge):this()
         {
             this.customerID = customerID;
             this.customerName = customerName;
             this.customerAge = customerAge;
                 this.customerAddress=customerAddress;
         }

        public string GetCustomerDetails()
        {
            return customerID + " " + customerName;
        }
    }
}
