﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace console_day2_op1
{
    partial class Test
    {
        public void setdata()
        {
        }

    }
}
