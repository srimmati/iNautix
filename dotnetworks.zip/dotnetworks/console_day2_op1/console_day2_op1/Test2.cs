﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace console_day2_op1
{
    class Test2
    {
        public string CustomerName
        {
            get;
            set;
        }
    }
}
