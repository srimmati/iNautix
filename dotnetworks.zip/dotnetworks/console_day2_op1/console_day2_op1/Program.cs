﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace console_day2_op1
{
    class Program
    {
        static void Main(string[] args)
        {
            Student st = new Student(1000, "ABCD");
            Console.WriteLine(st.pstudentId);
            st.pstudentName = "xxx";
            Console.WriteLine(st.pstudentName);
            st.pstudentMarks = 60;
            Console.WriteLine(st.pstudentMarks);
            Console.WriteLine(st.Pstudentstatus);
           
            /*Console.WriteLine("Ënter ID:");
            int customerID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter name:");
            string customerName =Console.ReadLine();
            Console.WriteLine("Enter Age:");
            int customerAge = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ënter address:");
            string customerAddress = Console.ReadLine();
            //Customer obj1 = new Customer();
            Customer obj = new Customer(customerID,customerName,customerAddress,customerAge);
            string detail=obj.GetCustomerDetails();
            Console.WriteLine(detail);
            obj.GEtdata("abc", 200);
            obj.GEtdata("xyz");
            obj.GEtdata(i: 300, str: "xyz"); */
            Console.ReadLine();

        }
    }
}
