﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_first_application
{
    /// <summary>
    /// Interaction logic for win_controls.xaml
    /// </summary>
    public partial class win_controls : Window
    {
        public win_controls()
        {
            InitializeComponent();
        }

        private void s1_number_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            txt_noofslider.Text = s1_number.Value.ToString();
        }
    }
}
