﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_first_application
{
    /// <summary>
    /// Interaction logic for new_user.xaml
    /// </summary>
    public partial class new_user : Window
    {
        public new_user()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txt_custid.Text = App.Current.Properties["UserID"].ToString();

        }
    }
}
