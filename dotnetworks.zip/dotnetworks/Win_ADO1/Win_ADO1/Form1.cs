﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
namespace Win_ADO1
{
    public partial class form1 : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public form1()
        {
            InitializeComponent();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_empid.Text = "";
            txt_empname.Text = "";
            cmb_empcity.Text = "";
            txt_empage.Text = "";
            txt_emppass.Text = "";
        }

        private void btn_addemp_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.EmployeeName = txt_empname.Text;
            obj.EmployeeCity = cmb_empcity.Text;
            obj.EmployeeAge = Convert.ToInt32(txt_empage.Text);
            obj.EmployeePassword = txt_emppass.Text;

            EmployeesDAL dal = new EmployeesDAL();
            dal.AddEmployee(obj);
            MessageBox.Show("Employee Added Successfully"+obj.EmployeeID);
        }

        private void btn_findemp_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_find_emp = new SqlCommand("select * from employees where employeeid=@empid", con);
            com_find_emp.Parameters.AddWithValue("@empid", txt_empid.Text);
            SqlDataReader dr = com_find_emp.ExecuteReader();
            if (dr.Read())
            {
                txt_empid.Text = dr.GetInt32(0).ToString();
                txt_empname.Text = dr.GetString(1);
                cmb_empcity.Text = dr.GetString(2);
                txt_empage.Text = dr.GetInt32(3).ToString();
                txt_emppass.Text = dr.GetString(4);

            }
            else
            {
                MessageBox.Show("Employee not found");
                  
            }
            con.Close();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_update_emp = new SqlCommand("update employees set employeename=@empname,employeecity=@empcity where employeeid=@empid", con);
            com_update_emp.Parameters.AddWithValue("@empname", txt_empname.Text);
            com_update_emp.Parameters.AddWithValue("@empcity", cmb_empcity.Text);
            com_update_emp.Parameters.AddWithValue("@empid", txt_empid.Text);
            int rows_affected = com_update_emp.ExecuteNonQuery();
            con.Close();
            if (rows_affected > 0)
            {
                MessageBox.Show("employee updated");
            }
            else
            {
                MessageBox.Show("employee not found");
            }
        }

        private void form1_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_cities = new SqlCommand("Select cityname from cities",con);
            SqlDataReader dr = com_cities.ExecuteReader();
            while (dr.Read())
            {
                cmb_empcity.Items.Add(dr.GetString(0));
                
            }
            con.Close();

        }

    }
}
