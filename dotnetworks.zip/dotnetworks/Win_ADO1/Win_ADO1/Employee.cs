﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ADO1
{
    class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeCity { get; set; }
        public int EmployeeAge { get; set; }
        public string EmployeePassword { get; set; }

    }
}
