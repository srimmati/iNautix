﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace day4_Generics
{
    class Program
    {
        static void Main(string[] args)
        { /*
            Test obj = new Test();
            int i = obj.GEtData<int>(100);
            string str = obj.GEtData<string>("hai pavithra gosh");
            Console.WriteLine(i);
            Console.WriteLine(str);

            ArrayList list = new ArrayList();
            list.Add("abc");
            list.Add(10);
            list.Add(true);
            int x = Convert.ToInt32(list[1]);
            string str = list[0].ToString();
            Console.WriteLine(x);
            Console.WriteLine(str); */
            Dictionary<int,float> m = new Dictionary<int, float>();
            m.Add(1, 1.1f);
            m.Add(2, 2.2f);
            Console.WriteLine(m[1]);


            List<int> marks = new List<int>();
            marks.Add(80);
            marks.Add(90);
            marks.Add(80);
            foreach (int i in marks)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine(marks.Count);
            Console.ReadLine();
        }
    }
}
