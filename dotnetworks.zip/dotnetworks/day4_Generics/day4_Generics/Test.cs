﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_Generics
{
    class Test
    {
        public T GEtData<T>(T str)
        {
            return str;
        }

    }
}
