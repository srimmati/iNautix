﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {

            
            string str = "sdf@ 8## fh f";
            str=str.Replace(" ","");
            char[] ch = str.ToCharArray();
            for (int i = 0; i < str.Length; i++)
            {
                
            }
            Console.WriteLine(str);
            Console.ReadLine();
        }
    }
}
