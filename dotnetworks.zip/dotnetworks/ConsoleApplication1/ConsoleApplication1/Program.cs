﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the employee ID");
            string empid = Console.ReadLine();
            Console.WriteLine("Enter employee name");
            string empname = Console.ReadLine();
            Console.WriteLine("EMPLOYEE ID:"+empid);
            Console.WriteLine("EMPLOYEE NAME:" + empname);
            Console.ReadLine();
        }
    }
}
