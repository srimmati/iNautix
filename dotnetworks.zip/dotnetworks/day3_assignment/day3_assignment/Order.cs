﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_assignment
{
    class Order
    {
        int orderid;
        string custname;
        int itemqty;
        int itemprice;
        public Order(int orderid, string custname, int itemqty, int itemprice)
        {
            this.orderid = orderid;
            this.custname = custname;
            this.itemprice = itemprice;
            this.itemqty = itemqty;
        }
        public virtual int getorderamt()
        {
            return itemqty * itemprice;
        }
    }
}
