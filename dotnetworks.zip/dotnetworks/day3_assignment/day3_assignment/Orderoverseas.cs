﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_assignment
{
    class Orderoverseas : Order
    {
        int oid;
        int iqty;
        int iprice;
        string cname;
        public Orderoverseas(int oid, string cname, int iqty, int iprice) : base(oid,cname,iqty,iprice)
        {
            this.oid = oid;
            this.cname = cname;
            this.iprice = iprice;
            this.iqty = iqty;
         
        }
        public override int getorderamt()
        {
            return (iqty * iprice) + 100;
        }

    }
}
