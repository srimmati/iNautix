﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter orderid,customername,itemquantity,itemprice");
            int orderid=Convert.ToInt32(Console.ReadLine());
            string custname = Console.ReadLine();
            int itemprice=Convert.ToInt32(Console.ReadLine());
            int itemqty=Convert.ToInt32(Console.ReadLine());

            Order obj;
            Console.WriteLine("ENTER THE TYPE OF ORDER:");
            string str = Console.ReadLine();
            if (str == "Order")
            {
                obj=new Order(orderid,custname,itemqty,itemprice);
            }
            else
            {
                obj=new Orderoverseas(orderid,custname,itemqty,itemprice);
            }
            int amt=obj.getorderamt();
            Console.WriteLine(amt);
            Console.ReadLine();
        }
    }
}
