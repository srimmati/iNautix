﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace day7_assignment_async
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public delegate int del_Calc(int n1, int n2,char str);
        public delegate void del();
        public int calc(int n1, int n2, char str)
        {
            Thread.Sleep(5000);
            int result = 0;
            switch (str)
            {
                case '+':
                    result= n1 + n2;
                    break;
                case '-':
                    result= n1 - n2;
                    break;
                case '*':
                    result= n1 * n2;
                    break;
                case '/':
                    result= n1 / n2;
                    break;
            }
            return result;
        }
        del_Calc obj;
        public void callback(IAsyncResult res)
        {
            MessageBox.Show("Let us calculate:");
            
            int result = obj.EndInvoke(res);
            del del_Calc=delegate()
            {
                lst_calc.Items.Add("RESULT:"+res.AsyncState + " : " + result);
            };
            this.BeginInvoke(del_Calc);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            obj = new del_Calc(calc);
        }
       
        private void btn_add_Click(object sender, EventArgs e)
        {
            int n1 = Convert.ToInt32(txt_number1.Text);
            int n2 = Convert.ToInt32(txt_number2.Text);
          
            obj.BeginInvoke(n1, n2, '+', new AsyncCallback(callback),n1+ "+" + n2 );
        }

        private void btn_sub_Click(object sender, EventArgs e)
        {
            int n1 = Convert.ToInt32(txt_number1.Text);
            int n2 = Convert.ToInt32(txt_number2.Text);

            obj.BeginInvoke(n1, n2, '-', new AsyncCallback(callback), n1 + "-" + n2);
        }

        private void btn_mul_Click(object sender, EventArgs e)
        {
            int n1 = Convert.ToInt32(txt_number1.Text);
            int n2 = Convert.ToInt32(txt_number2.Text);

            obj.BeginInvoke(n1, n2, '*', new AsyncCallback(callback), n1 + "*" + n2);
        }

        private void btn_div_Click(object sender, EventArgs e)
        {
            int n1 = Convert.ToInt32(txt_number1.Text);
            int n2 = Convert.ToInt32(txt_number2.Text);

            obj.BeginInvoke(n1, n2, '/', new AsyncCallback(callback), n1 + "/" + n2);
        }

      
    }
}
