﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_String
{
    class Program
    {
        static void Main(string[] args)
        { /*
            string str = "hello";
            string str1 = "abc";
            str = str1;
            str1 = "xyz";
            str1 = "hello";
            Console.WriteLine(str);
            Console.WriteLine(str1);
            
            foreach (char ch in str)
            {
                Console.WriteLine(ch);
            }
            string name = "abc";
            char[] chararray = { 'a', 'b', 'c' };

            object obj = new string(chararray);
            if (name == obj)
            {
                Console.WriteLine("== same");
            }
            else
            {
                Console.WriteLine("== false");
            }
            if (name.Equals(obj))
            {
                Console.WriteLine("equals true");

            }
            else
            {
                Console.WriteLine("equals false");
            } */


            int[][] jaggedarray = new int[3][];
            jaggedarray[0] = new int[2];
            jaggedarray[1] = new int[4];
            jaggedarray[2] = new int[1];

            jaggedarray[0][0] = 55;
            jaggedarray[0][1] = 66;

            jaggedarray[1][0] = 88;
            jaggedarray[1][1] = 89; 
            jaggedarray[1][2] = 90;
            jaggedarray[1][3] = 83;

            jaggedarray[2][0] = 68;

            foreach (int[] array in jaggedarray)
            {
                foreach (int x in array)
                {
                    Console.WriteLine(x);
                }
            }
           
            Console.ReadLine();
        }
    }
}
