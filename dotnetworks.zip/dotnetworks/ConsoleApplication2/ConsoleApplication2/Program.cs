﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Numerics;
namespace ConsoleApplication2
{
    class Program
    {
        static void Main(String[] args)
        {
            double d = 233.454;
            Console.WriteLine(Convert.ToString(12,16));
            Console.ReadKey();
        }


      
    }
}
