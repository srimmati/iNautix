﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Transactions;

namespace wcf_transaction_client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_buy_Click(object sender, EventArgs e)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {

                    ServiceReference_bank.ServiceClient bank_proxy = new ServiceReference_bank.ServiceClient("WSHttpBinding_IService");
                    int transid = bank_proxy.MakePayment(Convert.ToInt32(txt_accno.Text), Convert.ToInt32(txt_price.Text));
                    ServiceReference1_order.ServiceClient order_proxy = new ServiceReference1_order.ServiceClient("WSHttpBinding_IService1");
                    int orderid = order_proxy.PlaceOrder(Convert.ToInt32(txt_id.Text), Convert.ToInt32(txt_price.Text), transid, txt_name.Text);


                    scope.Complete();
                    MessageBox.Show("Order places successfully: orderid" + orderid + "transaction Id" + transid);
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show("Order is cancelled"+exp.Message);
            }
        }
    }
}
