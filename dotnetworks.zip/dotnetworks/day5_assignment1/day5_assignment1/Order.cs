﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day5_assignment1
{
    class Order
    {

        string custname, deliveryaddr, ordercity, orderdate;
         int orderid, itemid, itemqty, itemprice;
        bool paymentopt;
        public Order(string custname,string deliveryaddr,string ordercity,int orderid,int itemid,int itemprice,int itemqty,string orderdate)
        {
            this.itemprice=itemprice;
            this.itemqty=itemqty;
            this.custname = custname;
            this.deliveryaddr = deliveryaddr;
            this.ordercity = ordercity;
            this.orderdate = orderdate;
            this.orderid = orderid;
            this.itemid = itemid;
            this.orderid = orderid;
            this.orderdate = orderdate;
        }
        public int getorderamount()
        {

            int iqty = Convert.ToInt32(itemqty);
            int iprice = Convert.ToInt32(itemprice);
            int iid = Convert.ToInt32(itemid);
            int oid = Convert.ToInt32(orderid);
        
            int iorderamt = iqty * iprice;
            return iorderamt;
        }
        
    }
}
