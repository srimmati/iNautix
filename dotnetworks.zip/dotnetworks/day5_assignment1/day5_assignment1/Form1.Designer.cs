﻿namespace day5_assignment1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_id = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_itemid = new System.Windows.Forms.TextBox();
            this.txt_itemqty = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.txt_addr = new System.Windows.Forms.TextBox();
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.lbl_custname = new System.Windows.Forms.Label();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.lbl_itemqty = new System.Windows.Forms.Label();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.lbl_deladdr = new System.Windows.Forms.Label();
            this.lbl_orderdate = new System.Windows.Forms.Label();
            this.cmb_ordercity = new System.Windows.Forms.ComboBox();
            this.lbl_ordercity = new System.Windows.Forms.Label();
            this.rdb_cash = new System.Windows.Forms.RadioButton();
            this.lbl_paymentoption = new System.Windows.Forms.Label();
            this.rdb_credit = new System.Windows.Forms.RadioButton();
            this.rdb_debit = new System.Windows.Forms.RadioButton();
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.txt_orderdate = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(147, 38);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(100, 20);
            this.txt_id.TabIndex = 0;
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(147, 99);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(100, 20);
            this.txt_name.TabIndex = 1;
            this.txt_name.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txt_itemid
            // 
            this.txt_itemid.Location = new System.Drawing.Point(147, 169);
            this.txt_itemid.Name = "txt_itemid";
            this.txt_itemid.Size = new System.Drawing.Size(100, 20);
            this.txt_itemid.TabIndex = 2;
            // 
            // txt_itemqty
            // 
            this.txt_itemqty.Location = new System.Drawing.Point(147, 232);
            this.txt_itemqty.Name = "txt_itemqty";
            this.txt_itemqty.Size = new System.Drawing.Size(100, 20);
            this.txt_itemqty.TabIndex = 3;
            // 
            // txt_price
            // 
            this.txt_price.Location = new System.Drawing.Point(147, 297);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(100, 20);
            this.txt_price.TabIndex = 4;
            // 
            // txt_addr
            // 
            this.txt_addr.Location = new System.Drawing.Point(147, 357);
            this.txt_addr.Name = "txt_addr";
            this.txt_addr.Size = new System.Drawing.Size(100, 20);
            this.txt_addr.TabIndex = 5;
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Location = new System.Drawing.Point(13, 45);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(63, 13);
            this.lbl_orderid.TabIndex = 7;
            this.lbl_orderid.Text = "ORDERID :";
            // 
            // lbl_custname
            // 
            this.lbl_custname.AutoSize = true;
            this.lbl_custname.Location = new System.Drawing.Point(13, 99);
            this.lbl_custname.Name = "lbl_custname";
            this.lbl_custname.Size = new System.Drawing.Size(105, 13);
            this.lbl_custname.TabIndex = 8;
            this.lbl_custname.Text = "CUSTOMERNAME :";
            this.lbl_custname.Click += new System.EventHandler(this.lbl_custname_Click);
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Location = new System.Drawing.Point(13, 176);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(50, 13);
            this.lbl_itemid.TabIndex = 9;
            this.lbl_itemid.Text = "ITEMID :";
            // 
            // lbl_itemqty
            // 
            this.lbl_itemqty.AutoSize = true;
            this.lbl_itemqty.Location = new System.Drawing.Point(13, 239);
            this.lbl_itemqty.Name = "lbl_itemqty";
            this.lbl_itemqty.Size = new System.Drawing.Size(61, 13);
            this.lbl_itemqty.TabIndex = 10;
            this.lbl_itemqty.Text = "ITEMQTY :";
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Location = new System.Drawing.Point(13, 297);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(71, 13);
            this.lbl_itemprice.TabIndex = 11;
            this.lbl_itemprice.Text = "ITEMPRICE :";
            // 
            // lbl_deladdr
            // 
            this.lbl_deladdr.AutoSize = true;
            this.lbl_deladdr.Location = new System.Drawing.Point(16, 364);
            this.lbl_deladdr.Name = "lbl_deladdr";
            this.lbl_deladdr.Size = new System.Drawing.Size(121, 13);
            this.lbl_deladdr.TabIndex = 12;
            this.lbl_deladdr.Text = "DELIVERY ADDRESS :";
            // 
            // lbl_orderdate
            // 
            this.lbl_orderdate.AutoSize = true;
            this.lbl_orderdate.Location = new System.Drawing.Point(19, 411);
            this.lbl_orderdate.Name = "lbl_orderdate";
            this.lbl_orderdate.Size = new System.Drawing.Size(84, 13);
            this.lbl_orderdate.TabIndex = 13;
            this.lbl_orderdate.Text = "ORDER DATE :";
            // 
            // cmb_ordercity
            // 
            this.cmb_ordercity.FormattingEnabled = true;
            this.cmb_ordercity.Location = new System.Drawing.Point(147, 474);
            this.cmb_ordercity.Name = "cmb_ordercity";
            this.cmb_ordercity.Size = new System.Drawing.Size(121, 21);
            this.cmb_ordercity.TabIndex = 14;
            // 
            // lbl_ordercity
            // 
            this.lbl_ordercity.AutoSize = true;
            this.lbl_ordercity.Location = new System.Drawing.Point(22, 474);
            this.lbl_ordercity.Name = "lbl_ordercity";
            this.lbl_ordercity.Size = new System.Drawing.Size(79, 13);
            this.lbl_ordercity.TabIndex = 15;
            this.lbl_ordercity.Text = "ORDER CITY :";
            // 
            // rdb_cash
            // 
            this.rdb_cash.AutoSize = true;
            this.rdb_cash.Location = new System.Drawing.Point(162, 526);
            this.rdb_cash.Name = "rdb_cash";
            this.rdb_cash.Size = new System.Drawing.Size(102, 17);
            this.rdb_cash.TabIndex = 16;
            this.rdb_cash.TabStop = true;
            this.rdb_cash.Text = "CASH IN HAND";
            this.rdb_cash.UseVisualStyleBackColor = true;
            // 
            // lbl_paymentoption
            // 
            this.lbl_paymentoption.AutoSize = true;
            this.lbl_paymentoption.Location = new System.Drawing.Point(25, 526);
            this.lbl_paymentoption.Name = "lbl_paymentoption";
            this.lbl_paymentoption.Size = new System.Drawing.Size(109, 13);
            this.lbl_paymentoption.TabIndex = 17;
            this.lbl_paymentoption.Text = "PAYMENT OPTION :";
            // 
            // rdb_credit
            // 
            this.rdb_credit.AutoSize = true;
            this.rdb_credit.Location = new System.Drawing.Point(320, 526);
            this.rdb_credit.Name = "rdb_credit";
            this.rdb_credit.Size = new System.Drawing.Size(65, 17);
            this.rdb_credit.TabIndex = 18;
            this.rdb_credit.TabStop = true;
            this.rdb_credit.Text = "CREDIT";
            this.rdb_credit.UseVisualStyleBackColor = true;
            // 
            // rdb_debit
            // 
            this.rdb_debit.AutoSize = true;
            this.rdb_debit.Location = new System.Drawing.Point(471, 526);
            this.rdb_debit.Name = "rdb_debit";
            this.rdb_debit.Size = new System.Drawing.Size(57, 17);
            this.rdb_debit.TabIndex = 19;
            this.rdb_debit.TabStop = true;
            this.rdb_debit.Text = "DEBIT";
            this.rdb_debit.UseVisualStyleBackColor = true;
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Location = new System.Drawing.Point(147, 560);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(117, 23);
            this.btn_placeorder.TabIndex = 20;
            this.btn_placeorder.Text = "PLACE ORDER";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(320, 560);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 21;
            this.btn_reset.Text = "RESET";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // txt_orderdate
            // 
            this.txt_orderdate.Location = new System.Drawing.Point(147, 404);
            this.txt_orderdate.Name = "txt_orderdate";
            this.txt_orderdate.Size = new System.Drawing.Size(100, 20);
            this.txt_orderdate.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 609);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_placeorder);
            this.Controls.Add(this.rdb_debit);
            this.Controls.Add(this.rdb_credit);
            this.Controls.Add(this.lbl_paymentoption);
            this.Controls.Add(this.rdb_cash);
            this.Controls.Add(this.lbl_ordercity);
            this.Controls.Add(this.cmb_ordercity);
            this.Controls.Add(this.lbl_orderdate);
            this.Controls.Add(this.lbl_deladdr);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.lbl_itemqty);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.lbl_custname);
            this.Controls.Add(this.lbl_orderid);
            this.Controls.Add(this.txt_orderdate);
            this.Controls.Add(this.txt_addr);
            this.Controls.Add(this.txt_price);
            this.Controls.Add(this.txt_itemqty);
            this.Controls.Add(this.txt_itemid);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.txt_id);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox txt_itemid;
        private System.Windows.Forms.TextBox txt_itemqty;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.TextBox txt_addr;
        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Label lbl_custname;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.Label lbl_itemqty;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.Label lbl_deladdr;
        private System.Windows.Forms.Label lbl_orderdate;
        private System.Windows.Forms.ComboBox cmb_ordercity;
        private System.Windows.Forms.Label lbl_ordercity;
        private System.Windows.Forms.RadioButton rdb_cash;
        private System.Windows.Forms.Label lbl_paymentoption;
        private System.Windows.Forms.RadioButton rdb_credit;
        private System.Windows.Forms.RadioButton rdb_debit;
        private System.Windows.Forms.Button btn_placeorder;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.TextBox txt_orderdate;
    }
}

