﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace day5_assignment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_custname_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_ordercity.Items.Add("MADURAI");
            cmb_ordercity.Items.Add("COIMBATORE");
            cmb_ordercity.Items.Add("MUMBAI");
            cmb_ordercity.Items.Add("RAMANATHAPURAM");
            cmb_ordercity.Items.Add("RAMESHWARAM");
        }

        private void btn_placeorder_Click(object sender, EventArgs e)
        {
            int oid = Convert.ToInt32(txt_id.Text);
            string cname = txt_name.Text;
            int iid = Convert.ToInt32(txt_itemid.Text);
            int iqty = Convert.ToInt32(txt_itemqty.Text);
            int iprice = Convert.ToInt32(txt_price.Text);
            string addr = txt_addr.Text;
            string odate = txt_orderdate.Text;
            string corder = cmb_ordercity.Text;
            string popt = "";
            if (rdb_cash.Checked)
            {
                popt = "cash";
            }
            else if (rdb_debit.Checked)
            {
                popt = "Debit";
            }
            else if (rdb_credit.Checked)
            {
                popt = "Credit";
            }
            if (oid == null)
            {
                MessageBox.Show("ENTER ORDERID");
            }
            
            else if (cname == "")
            {
                MessageBox.Show("ENTER CUSTOMERNAME");
            }
            
            else if (iid == null)
            {
                MessageBox.Show("ENTER ITEMID");
            }
            
            else if (iqty == null)
            {
                MessageBox.Show("ENTER ITEMQUANTITY");
            }
            
            else if (iprice == null)
            {
                MessageBox.Show("ENTER ITEMPRICE");
            }
            
            else if (addr == "")
            {
                MessageBox.Show("ENTER ADDRESS");
            }
           
            else if (odate == "")
            {
                MessageBox.Show("ENTER ORDERDATE");
            }
            else if (corder == null)
            {
                MessageBox.Show("SELECT CITY NAME");
            }
            else if (popt == "")
            {
                MessageBox.Show("Please select a payment option");
            }
            
            else
            {
                Order obj = new Order(cname,addr,corder,oid,iid,iprice,iqty,odate);
                int amount = obj.getorderamount();
                MessageBox.Show("ORDER AMOUNT:" + amount);
            }
          }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_addr.Text = "";
            txt_orderdate.Text = "";
            txt_id.Text = "";
            txt_itemid.Text = "";
            txt_itemqty.Text = "";
            txt_name.Text = "";
            txt_price.Text = "";
            cmb_ordercity.Text = "";
            rdb_cash.Checked = false;
            rdb_credit.Checked = false;
            rdb_debit.Checked = false;
        }

        private void mc_date_DateChanged(object sender, DateRangeEventArgs e)
        {
            MessageBox.Show(e.Start.ToString());
            MessageBox.Show(e.End.ToString());

        }
    }
}
