﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace day5_winfirstappn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_loginid_Click(object sender, EventArgs e)
        {

        }

        private void btn_login_Click(object sender, EventArgs e)
        {

            string userid = txt_login.Text;
            string password = txt_password.Text;
            if (userid == "")
            {
                MessageBox.Show("Enter user id");
            }
            else if (password == "") 
            {
                MessageBox.Show("Enter password");

            }
            else
            {
                 
            if (userid == "sripavi" && password == "pavisri")
            {
                MessageBox.Show("Welcome here !!");
                day5_frm_Home obj = new day5_frm_Home();
                obj.Show();
            }
            else
            {
                MessageBox.Show("userid or password incorrect");
            }
            }


        }
    }
}
