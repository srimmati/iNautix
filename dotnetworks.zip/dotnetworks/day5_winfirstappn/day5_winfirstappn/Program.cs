﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace day5_winfirstappn
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new day5_frm_Home());
        }
    }
}
