﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace day5_winfirstappn
{
    public partial class day5_frm_Home : Form
    {
        public day5_frm_Home()
        {
            InitializeComponent();
        }

        private void day5_frm_Home_Load(object sender, EventArgs e)
        {
            lst_city.Items.Add("chennai");
            lst_city.Items.Add("Madurai");
            lst_city.Items.Add("Pune");
            cmb_itemid.Items.Add("1001");
            cmb_itemid.Items.Add("1002");
            cmb_itemid.Items.Add("1003");
        }

        private void btn_getcity_Click(object sender, EventArgs e)
        {
            string gender = "";
            if (rdb_female.Checked)
            {
                gender = "male";
            }
            else if (rdb_male.Checked)
            {
                gender = "female";
            }
            if(gender=="")
            {
                MessageBox.Show("select gender");

            }
            if (chk_orderstatus.Checked)
            {
                MessageBox.Show("ORDER IS COMPLETED");
            }
            else
            {
                MessageBox.Show("Order is pending");
            }
            string city = lst_city.Text;
            if (city == "")
            {
                MessageBox.Show("Select a city");
            }
            else
            {
                MessageBox.Show("ÿou have selected : " + city);
            }

        }

        private void cmb_itemid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
