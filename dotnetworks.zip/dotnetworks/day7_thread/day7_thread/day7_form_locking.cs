﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace day7_thread
{
    public partial class day7_form_locking : Form
    {
        public day7_form_locking() 
        {
            InitializeComponent();
        }
        int total;
        public void sum()
        {
            int num1 = Convert.ToInt32(txt_num1.Text);
            int num2 = Convert.ToInt32(txt_num2.Text);
            //lock (this)
            {
                //Monitor.Enter(this);
                if (Monitor.TryEnter(this,5000))
                {
                    total = num1 + num2;
                    Thread.Sleep(5000);

                    MessageBox.Show("Total:" + total);
                    Monitor.Exit(this);
                }
                else
                {
                    MessageBox.Show("not released");
                }
            }
            
        }
        private void btn_thread1_Click(object sender, EventArgs e)
        {
            Thread th1 = new Thread(sum);
            th1.Start();
        }

        private void btn_thread2_Click(object sender, EventArgs e)
        {
            Thread th2 = new Thread(sum);
            th2.Start();
        }
    }
}
