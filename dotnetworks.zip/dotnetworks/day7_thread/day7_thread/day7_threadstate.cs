﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace day7_thread
{
    public partial class day7_threadstate : Form
    {
        public day7_threadstate()
        {
            InitializeComponent();
        }
        Bitmap b1 = new Bitmap(@"C:\Users\Public\Pictures\Sample Pictures\Chrysanthemum.jpg");
        Bitmap b2 = new Bitmap(@"C:\Users\Public\Pictures\Sample Pictures\Koala.jpg");
        Bitmap b3 = new Bitmap(@"C:\Users\Public\Pictures\Sample Pictures\Penguins.jpg");
        Bitmap b4 = new Bitmap(@"C:\Users\Public\Pictures\Sample Pictures\Tulips.jpg");
        Bitmap b5 = new Bitmap(@"C:\Users\Public\Pictures\Sample Pictures\Desert.jpg");
        public void showimages()
        {
            while (true)
            {
                pic_viewer.Image = b1;
                Thread.Sleep(2000);
                pic_viewer.Image = b2;
                Thread.Sleep(2000);
                pic_viewer.Image = b3;
                Thread.Sleep(2000);
                pic_viewer.Image = b4;
                Thread.Sleep(2000);
                pic_viewer.Image = b5;
                Thread.Sleep(2000);


            }
        }
        Thread th;
        private void btn_Start_Click(object sender, EventArgs e)
        {
            th = new Thread(showimages);
            th.IsBackground = true;
            th.Start();
            btn_Start.Enabled = false;
        }

        private void btn_pause_Click(object sender, EventArgs e)
        {
            th.Suspend();
        }

        private void btn_resume_Click(object sender, EventArgs e)
        {
            th.Resume();
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            th.Abort();
        }

       
    }
}
