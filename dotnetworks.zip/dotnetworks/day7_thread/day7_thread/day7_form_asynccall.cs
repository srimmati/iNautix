﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace day7_thread
{
    public partial class day7_form_asynccall : Form
    {
        public day7_form_asynccall()
        {
            InitializeComponent();
        }
        public delegate int del_sum(int n1, int n2);
        public delegate void del();
        public int GetSum(int n1, int n2)
        {
            MessageBox.Show("GETSUM");
            return n1 + n2;
        }
        public void callback(IAsyncResult res)
        {
            MessageBox.Show("Get sum called succefully");
            int result = obj.EndInvoke(res);
            MessageBox.Show("RESULT:"+res.AsyncState+":" + result);
            del delobj=delegate()
            {
               lst_results.Items.Add(res.AsyncState + ":" + result);
            };
            this.BeginInvoke(delobj);
        }
        del_sum obj;
        private void btn_async_Click(object sender, EventArgs e)
        {
            obj = new del_sum(GetSum);
            obj.BeginInvoke(100, 200, new AsyncCallback(callback),"100+200");
            
            MessageBox.Show("main thread");
        }

        private void day7_form_asynccall_Load(object sender, EventArgs e)
        {

        }

        
    }
}
