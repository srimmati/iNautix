﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace day7_thread
{
    public partial class day7_form_join_autoresetevent : Form
    {
        public day7_form_join_autoresetevent()
        {
            InitializeComponent();
        }
        public void call()
        {
            MessageBox.Show("Call function 1");
            wait.Set();
            MessageBox.Show("Call function 2");
        }
        AutoResetEvent wait = new AutoResetEvent(false);
        private void day7_form_join_autoresetevent_Load(object sender, EventArgs e)
        {

        }

        private void btn_join_Click(object sender, EventArgs e)
        {
            Thread th = new Thread(call);
            th.Start();
            MessageBox.Show("Main thread 1");
            wait.WaitOne();
            //th.Join();
            MessageBox.Show("Main thread 2");
        }
    }
}
