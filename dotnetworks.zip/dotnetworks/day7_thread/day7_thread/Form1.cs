﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace day7_thread
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_newthread_Click(object sender, EventArgs e)
        {
            ThreadStart th_del1 = new ThreadStart(call1);
            Thread th1 = new Thread(th_del1);
            th1.IsBackground = true;
            th1.Start();
            ThreadStart th2_del = new ThreadStart(call2);
            Thread th2 = new Thread(th2_del);
            th2.IsBackground = true;
            th2.Start();
            MessageBox.Show("Main thread!");
        }
        public void call1()
        {
            MessageBox.Show("Call1 function" +Thread.CurrentThread.ManagedThreadId);
        }
        public void call2()
        {
            MessageBox.Show("Call2 function" + Thread.CurrentThread.ManagedThreadId);
        }
    }
}