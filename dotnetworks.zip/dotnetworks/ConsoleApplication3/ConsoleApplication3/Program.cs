﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            //string str = Console.ReadLine();
         //   string[] arr = str.Split(' ');
          //  int[] num = Array.ConvertAll(arr, Int32.Parse);
          //  Array.Sort(num);
          //  foreach (int x in num)
          //  {
           //     Console.WriteLine(x);

           // }

       
       //     string a = Convert.ToString(10,16);
        
            
            /*int vow = 0;
            int con = 0;

            string xyz = Console.ReadLine();
            string x = xyz.ToLower();
            char[] ch = x.ToCharArray();
            for (int i = 0; i < ch.Length; i++)
            {
                if (ch[i] == 'a' || ch[i] == 'e' || ch[i] == 'i' || ch[i] == 'o' || ch[i] == 'u')
                {

                    vow = vow + 1;
                }
                else
                {
                    con = con + 1;
                }

            
            }*/



            /*
            int sum = 0;
            int x =Convert.ToInt32(Console.ReadLine());
            int y = Convert.ToInt32(Console.ReadLine());
            for (int i = x + 1; i < y ; i++)
            {

                int fact = 1;
                for (int j = 1; j<=i; j++)
                {
                    fact = fact * j;

                }

                Console.WriteLine(fact);
                sum = sum + fact;
            
            }
             */
       

         /*   string str = Console.ReadLine();
            int[] count = new int[256];

            char[] ch = str.ToCharArray();
            for (int i = 0; i < str.Length; i++)
            {
                count[ch[i]]++;
            }

            for (int i = 97; i < 123;i++ )

            {
                if (count[i] != 0)
                {
                    char x = Convert.ToChar(i);
                    Console.WriteLine(x + " " + count[i]);

                }
                }
            */
        
        //BigInteger b=new BigInteger(15555556);

        //double num =23.4567578 ;

        //string t= DateTime.Now.ToShortDateString();
            
            
           
            string str = Console.ReadLine();
            char[] ch=str.ToCharArray();
            Array.Reverse(ch);
            string s = new string(ch);
            
            if (s.Equals(str))
            {
                Console.WriteLine("Yes");
            }
             
            Console.ReadLine();
                
       
        }
    }
}
