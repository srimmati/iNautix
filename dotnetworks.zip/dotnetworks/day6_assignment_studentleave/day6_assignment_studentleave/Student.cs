﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day6_assignment_studentleave
{
    class Student
    {
        public delegate void delstud(int rollno, string msg);
        public event delstud evt_req;
        public void request(string msg)
        {
            if(evt_req!=null)
            {
                evt_req(rollno,msg);
            }
        }
        int rollno;
        public int Prollno
        {
            get
            {
                return rollno;
            }
        }
    
        string studName;
        string city;
        public Student(int rollno , string studName, string city)
        {
            this.rollno = rollno;
            this.studName = studName;
            this.city = city;
        }
        public override string ToString()
        {
            return rollno + " " + studName + " " + city;
        }
    }
}
