﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day6_assignment_studentleave
{
    class College
    {
        int CollegeID;
        string CollegeName;
        List<Student> studlist = new List<Student>();
        List<Student> studlist_request = new List<Student>();
        
        public College(int CollegeID, string CollegeName)
        {
            this.CollegeID = CollegeID;
            this.CollegeName = CollegeName;
        }
        public void notify(int rollno, string msg)
        {
            Console.WriteLine("College:" + rollno + " :" + msg);
            studlist_request.Add(SearchStudent(rollno));
        }
               
        public void AddStudent(Student stu)
        {
            studlist.Add(stu);
            stu.evt_req += new Student.delstud(notify);//bind
        }
        public bool RemoveStudent(int rollno)
        {
            foreach (Student s in studlist)
            {
                if (s.Prollno == rollno)
                {
                    studlist.Remove(s);
                    return true;
                }
             }
            return false;
        }
        public Student SearchStudent(int rollno)
        {
            foreach (Student s in studlist)
            {
                if (s.Prollno == rollno)
                {
                    return s;
                }
            }
            return null;
        }
        public void ShowStudents()
        {
            foreach (Student s in studlist)
            {
                Console.WriteLine(s.ToString());
            }
        }
    }
}
