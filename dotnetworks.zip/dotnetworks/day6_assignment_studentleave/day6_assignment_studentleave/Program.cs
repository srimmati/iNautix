﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day6_assignment_studentleave
{
    class Program
    {
        static void Main(string[] args)
        {
            College college = new College(1001,"Thiagarajar");
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1.ADD,2.REMOVE,3.FIND,4.SHOW,5.EXIT");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        Console.WriteLine("enter id,name,city:");
                        int studid = Convert.ToInt32(Console.ReadLine());
                        string studname = Console.ReadLine();
                        string studcity = Console.ReadLine();
                        Student obj = new Student(studid, studname, studcity);
                        college.AddStudent(obj);
                        break;

                    case 2:
                        Console.WriteLine("Ënter rollno:");
                        int stid = Convert.ToInt32(Console.ReadLine());
                        bool status = college.RemoveStudent(stid);
                        if (status == true)
                        {
                            Console.WriteLine("successfully removed");
                        }
                        else
                        {
                            Console.WriteLine("not found");
                        }
                        break;

                    case 3:
                        Console.WriteLine("enter rollno");
                        int sid = Convert.ToInt32(Console.ReadLine());
                        Student stnd = college.SearchStudent(sid);
                        if (stnd == null)
                        {
                            Console.WriteLine("Student not found");

                        }
                        else
                        {
                            Console.WriteLine("Ënter 1:show,2.Leave request:");
                            int option = Convert.ToInt32(Console.ReadLine());
                            if (option == 1)
                            {
                                Console.WriteLine(stnd.ToString());
                            }
                            else
                            {
                                Console.WriteLine("Ener the reason:");
                                string reason = Console.ReadLine();
                                stnd.request(reason);
                            }

                        }
                        break;
                    case 4:

                        college.ShowStudents();
                        break;
                    case 5:
                        flag = false;
                        break;
                   

                }
            }
        }
        }
    }

