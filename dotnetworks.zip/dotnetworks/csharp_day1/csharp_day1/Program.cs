﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace csharp_day1
{
    class Program
    {
        static void Main(string[] args)
        {
           /* int marks = 100;
            bool st = true;

            double d = 22.34;
            string s = "hello";

            DateTime dt = DateTime.Now;
            DateTime dt1 = Convert.ToDateTime("12/12/2017");
            DateTime dt2 = dt1.AddDays(60);
            Console.WriteLine(dt1);
            Console.WriteLine(dt2);
            Console.WriteLine(dt.ToLongDateString());
            TimeSpan t = dt2 - dt1;
            Console.WriteLine(t.TotalHours); */
            /*int marks;
            Console.WriteLine("Enter the marks");
            marks = Convert.ToInt32(Console.ReadLine());
            if (marks > 50)
            {
                Console.WriteLine("Pass");
            }
            else
            {
                Console.WriteLine("Fail");
            }
            int counter = 0;
            while (counter < 10)
            {
                Console.WriteLine(counter);
                counter++;
            }
            for (int i = 0; i < 10; i++)
            {
                Console.Write(i + " ");
            } 
            int[] a = new int[5];
            a[0] = 85;
            a[1] = 75;
            a[2] = 65;
            a[3] = 55;
            a[4] = 45; */
            Console.WriteLine("enter nos");
            /* for (int i = 0; i < a.Length; i++)
            {
                a[i] =Convert.ToInt32( Console.ReadLine());
            }
           for (int i = 0; i < a.Length; i++)
            {
                Console.WriteLine(a[i]);
            }
            foreach (int x in a)
            {
                Console.WriteLine(x);
            } 
            int option = 0;
            switch (option)
            {
                case 1:
                    Console.WriteLine("one");
                    break;
                case 2:
                    Console.WriteLine("two");
                    break;
                default:
                    Console.WriteLine("default");
                    break;

            }*/
            Console.ReadLine(); 
        }
    }
}
