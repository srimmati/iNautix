﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_Abstract_Accounts
{
    class Saving : Account 
    {
        public Saving(int AccountID, string CustomerName, int AccountBal)
            : base(AccountID, CustomerName, AccountBal)
        {

        }


        public override bool Withdraw(int amt)
        {
            if ((AccountBal - amt) > 500)
            {
                AccountBal = AccountBal - amt;
                return true;
            }
            else
            {
                return false;
            }

        }

        public override bool Deposit(int amt)
        {
            AccountBal = AccountBal + amt + 100;
            return true;
        }
    }
}
