﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_Abstract_Accounts
{
    abstract class Account
    {
        protected int AccountID;
        protected string CustomerName;
        protected int AccountBal;
        public Account(int AccountID, string CustomerName, int AccountBal)
        {
            this.AccountBal = AccountBal;
            this.AccountID = AccountID;
            this.CustomerName = CustomerName;
            Console.WriteLine("constructor called");
        }
        public void StopPayment()
        {
            Console.WriteLine("STOPPAYMENT");
        }
        public int GetBalance()
        {
            return AccountBal;
        }
        public void GetStatement()
        {
            Console.WriteLine("BANK STATEMENT");
        }
        public abstract bool Withdraw(int amt);
        public abstract bool Deposit(int amt);
    }
}
