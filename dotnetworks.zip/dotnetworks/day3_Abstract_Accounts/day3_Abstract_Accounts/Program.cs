﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_Abstract_Accounts
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter account id");
            int accntid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter customer name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter account bal");
            int accntbal = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter type of account");
            string type = Console.ReadLine();
            Account obj;
            if (type == "saving")
            {
                obj = new Saving(accntid, name, accntbal);

            }
            else
            {
                obj=new Current(accntid,name,accntbal);
            }
            int bal = obj.GetBalance();
            Console.WriteLine("your bal is" + bal);
            obj.Deposit(2500);
            bal = obj.GetBalance();
            Console.WriteLine("your bal is" + bal);
            obj.Withdraw(2000);
            bal = obj.GetBalance();
            Console.WriteLine("your bal is" + bal);
            obj.StopPayment();
            Console.ReadLine();
        }
    }
}
