﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_assignment
{
    interface IManager
    {
        string getemployeepd();
        int getemployeeid();
        int getemployeeexp();
    }
}
