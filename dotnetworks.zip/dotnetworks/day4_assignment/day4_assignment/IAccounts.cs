﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_assignment
{
    interface IAccounts
    {
         int getemployeesalary();
        int getemployeeid();
        int getemployeeaccno();
    }
}
