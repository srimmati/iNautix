﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_assignment
{
    class Manager
    {
        public void Managerresult(IManager obj)
        {
            int id = obj.getemployeeid();
            int exp = obj.getemployeeexp();
            string pd = obj.getemployeepd();
            Console.WriteLine("EmployeeID:"+id);
            Console.WriteLine("Employeeprojectdetails:"+pd);
            Console.WriteLine("Employee exp:"+exp);
        }
    }
}
