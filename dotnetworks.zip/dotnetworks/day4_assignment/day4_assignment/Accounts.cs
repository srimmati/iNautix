﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_assignment
{
    class Accounts
    {
        public void Accountsresult(IAccounts obj)
        {
            int salary = obj.getemployeesalary();
            int id = obj.getemployeeid();
            int accno = obj.getemployeeaccno();
            Console.WriteLine("EmployeeID:" + id);
            Console.WriteLine("Employee Accno:" + accno);
            Console.WriteLine("Employee salary:" + salary);
        }
    }
}
