﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_assignment
{
    class HR
    {
        public void HRresult(IHR obj)
        {
            string address = obj.getemployeeadress();
            int id = obj.getemployeeid();
            int salary = obj.getemployeesalary();
            Console.WriteLine("EmployeeID:" + id);
            Console.WriteLine("Employeesalary:" + salary);
            Console.WriteLine("Employee address:" + address);
        }
    }
}
