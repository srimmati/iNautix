﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee e = new Employee();
            e.exp = 10;
            e.city = "Madurai";
            e.bankname = "ICICI";
            e.age = 45;
            e.address = "S.S.COLONY";
            e.accno = 313177;
            e.name = "sripavi";
            e.id = 37;
            e.pd = "DOTNET";
            e.sal = 45000;
            Console.WriteLine("enter if HR or MANAGER or ACCOUNTS");
            string str = Console.ReadLine();
            if (str == "MANAGER")
            {
                Manager mobj = new Manager();
                mobj.Managerresult(e);
            }
            else if (str == "HR")
            {
                HR hobj = new HR();
                hobj.HRresult(e);
            }
            else
            {
                Accounts aobj = new Accounts();
                aobj.Accountsresult(e);
            }
            Console.ReadLine();
        }       
    }
}
