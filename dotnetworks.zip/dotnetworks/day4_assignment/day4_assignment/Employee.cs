﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_assignment
{
    class Employee : IHR,IAccounts,IManager
    {
        public int id, sal, exp, accno, age;
        public string name, city, address, pd, bankname;


        public string getemployeeadress()
        {
            return address;
        }

        public int getemployeeid()
        {
            return id;
        }

        public int getemployeesalary()
        {
            return sal;
        }


        public int getemployeeaccno()
        {
            return accno;
        }

        public string getemployeepd()
        {
            return pd;
        }

        public int getemployeeexp()
        {
            return exp;
        }
    }
}
