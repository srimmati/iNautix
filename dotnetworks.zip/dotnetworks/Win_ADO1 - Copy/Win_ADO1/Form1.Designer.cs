﻿namespace Win_ADO1
{
    partial class form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_empid = new System.Windows.Forms.Label();
            this.lbl_empname = new System.Windows.Forms.Label();
            this.lbl_empcity = new System.Windows.Forms.Label();
            this.lbl_empage = new System.Windows.Forms.Label();
            this.lbl_emppass = new System.Windows.Forms.Label();
            this.txt_empid = new System.Windows.Forms.TextBox();
            this.txt_empname = new System.Windows.Forms.TextBox();
            this.txt_empage = new System.Windows.Forms.TextBox();
            this.txt_emppass = new System.Windows.Forms.TextBox();
            this.btn_addemp = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_findemp = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.cmb_empcity = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_empid
            // 
            this.lbl_empid.AutoSize = true;
            this.lbl_empid.Location = new System.Drawing.Point(39, 52);
            this.lbl_empid.Name = "lbl_empid";
            this.lbl_empid.Size = new System.Drawing.Size(73, 13);
            this.lbl_empid.TabIndex = 0;
            this.lbl_empid.Text = "Employee ID :";
            // 
            // lbl_empname
            // 
            this.lbl_empname.AutoSize = true;
            this.lbl_empname.Location = new System.Drawing.Point(42, 89);
            this.lbl_empname.Name = "lbl_empname";
            this.lbl_empname.Size = new System.Drawing.Size(90, 13);
            this.lbl_empname.TabIndex = 1;
            this.lbl_empname.Text = "Employee Name :";
            // 
            // lbl_empcity
            // 
            this.lbl_empcity.AutoSize = true;
            this.lbl_empcity.Location = new System.Drawing.Point(41, 128);
            this.lbl_empcity.Name = "lbl_empcity";
            this.lbl_empcity.Size = new System.Drawing.Size(73, 13);
            this.lbl_empcity.TabIndex = 2;
            this.lbl_empcity.Text = "Employee City";
            // 
            // lbl_empage
            // 
            this.lbl_empage.AutoSize = true;
            this.lbl_empage.Location = new System.Drawing.Point(37, 176);
            this.lbl_empage.Name = "lbl_empage";
            this.lbl_empage.Size = new System.Drawing.Size(81, 13);
            this.lbl_empage.TabIndex = 3;
            this.lbl_empage.Text = "Employee Age :";
            // 
            // lbl_emppass
            // 
            this.lbl_emppass.AutoSize = true;
            this.lbl_emppass.Location = new System.Drawing.Point(40, 219);
            this.lbl_emppass.Name = "lbl_emppass";
            this.lbl_emppass.Size = new System.Drawing.Size(102, 13);
            this.lbl_emppass.TabIndex = 4;
            this.lbl_emppass.Text = "Employee Password";
            // 
            // txt_empid
            // 
            this.txt_empid.Location = new System.Drawing.Point(193, 53);
            this.txt_empid.Name = "txt_empid";
            this.txt_empid.Size = new System.Drawing.Size(125, 20);
            this.txt_empid.TabIndex = 5;
            // 
            // txt_empname
            // 
            this.txt_empname.Location = new System.Drawing.Point(193, 87);
            this.txt_empname.Name = "txt_empname";
            this.txt_empname.Size = new System.Drawing.Size(125, 20);
            this.txt_empname.TabIndex = 6;
            // 
            // txt_empage
            // 
            this.txt_empage.Location = new System.Drawing.Point(193, 172);
            this.txt_empage.Name = "txt_empage";
            this.txt_empage.Size = new System.Drawing.Size(125, 20);
            this.txt_empage.TabIndex = 8;
            // 
            // txt_emppass
            // 
            this.txt_emppass.Location = new System.Drawing.Point(193, 219);
            this.txt_emppass.Name = "txt_emppass";
            this.txt_emppass.Size = new System.Drawing.Size(125, 20);
            this.txt_emppass.TabIndex = 9;
            // 
            // btn_addemp
            // 
            this.btn_addemp.Location = new System.Drawing.Point(106, 282);
            this.btn_addemp.Name = "btn_addemp";
            this.btn_addemp.Size = new System.Drawing.Size(94, 31);
            this.btn_addemp.TabIndex = 10;
            this.btn_addemp.Text = "Add Employee";
            this.btn_addemp.UseVisualStyleBackColor = true;
            this.btn_addemp.Click += new System.EventHandler(this.btn_addemp_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(269, 283);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(111, 29);
            this.btn_clear.TabIndex = 11;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_findemp
            // 
            this.btn_findemp.Location = new System.Drawing.Point(429, 289);
            this.btn_findemp.Name = "btn_findemp";
            this.btn_findemp.Size = new System.Drawing.Size(93, 23);
            this.btn_findemp.TabIndex = 12;
            this.btn_findemp.Text = "Find Employee";
            this.btn_findemp.UseVisualStyleBackColor = true;
            this.btn_findemp.Click += new System.EventHandler(this.btn_findemp_Click);
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(429, 118);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 23);
            this.btn_update.TabIndex = 13;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // cmb_empcity
            // 
            this.cmb_empcity.FormattingEnabled = true;
            this.cmb_empcity.Location = new System.Drawing.Point(193, 128);
            this.cmb_empcity.Name = "cmb_empcity";
            this.cmb_empcity.Size = new System.Drawing.Size(121, 21);
            this.cmb_empcity.TabIndex = 14;
            // 
            // form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 395);
            this.Controls.Add(this.cmb_empcity);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_findemp);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_addemp);
            this.Controls.Add(this.txt_emppass);
            this.Controls.Add(this.txt_empage);
            this.Controls.Add(this.txt_empname);
            this.Controls.Add(this.txt_empid);
            this.Controls.Add(this.lbl_emppass);
            this.Controls.Add(this.lbl_empage);
            this.Controls.Add(this.lbl_empcity);
            this.Controls.Add(this.lbl_empname);
            this.Controls.Add(this.lbl_empid);
            this.Name = "form1";
            this.Text = "City";
            this.Load += new System.EventHandler(this.form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_empid;
        private System.Windows.Forms.Label lbl_empname;
        private System.Windows.Forms.Label lbl_empcity;
        private System.Windows.Forms.Label lbl_empage;
        private System.Windows.Forms.Label lbl_emppass;
        private System.Windows.Forms.TextBox txt_empid;
        private System.Windows.Forms.TextBox txt_empname;
        private System.Windows.Forms.TextBox txt_empage;
        private System.Windows.Forms.TextBox txt_emppass;
        private System.Windows.Forms.Button btn_addemp;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_findemp;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.ComboBox cmb_empcity;
    }
}

