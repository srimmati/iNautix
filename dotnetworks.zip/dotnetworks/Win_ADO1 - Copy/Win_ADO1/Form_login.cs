﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_ADO1
{
    public partial class Form_login : Form
    {
        SqlCommand con = new SqlCommand(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public Form_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            SqlCommand com_login = new SqlCommand("select count(*) from employees where employeeid=@empid and employeepassword=@emppwd", con);
            com_login.Parameters.AddWithValue("@empid", txt_empid.Text);
            com_login.Parameters.AddWithValue("@emppwd", txt_pass.Text);
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                MessageBox.Show("valid user");
                form1 obj = new form1();
                obj.Show();

            }
            else
            {
                MessageBox.Show("Invalid User");
            }
        }
    }
}
