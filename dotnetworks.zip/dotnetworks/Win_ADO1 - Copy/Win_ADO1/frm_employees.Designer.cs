﻿namespace Win_ADO1
{
    partial class frm_employees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_showemployee = new System.Windows.Forms.Button();
            this.dg_employees = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.btn_searchemployee = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_showemployee
            // 
            this.btn_showemployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_showemployee.Location = new System.Drawing.Point(81, 55);
            this.btn_showemployee.Name = "btn_showemployee";
            this.btn_showemployee.Size = new System.Drawing.Size(158, 41);
            this.btn_showemployee.TabIndex = 0;
            this.btn_showemployee.Text = "Show Employee";
            this.btn_showemployee.UseVisualStyleBackColor = true;
            this.btn_showemployee.Click += new System.EventHandler(this.btn_showemployee_Click);
            // 
            // dg_employees
            // 
            this.dg_employees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_employees.Location = new System.Drawing.Point(81, 119);
            this.dg_employees.Name = "dg_employees";
            this.dg_employees.Size = new System.Drawing.Size(541, 243);
            this.dg_employees.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(81, 55);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(158, 41);
            this.button1.TabIndex = 0;
            this.button1.Text = "Show Employee";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btn_showemployee_Click);
            // 
            // txt_city
            // 
            this.txt_city.Location = new System.Drawing.Point(457, 67);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(153, 20);
            this.txt_city.TabIndex = 2;
            // 
            // btn_searchemployee
            // 
            this.btn_searchemployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_searchemployee.Location = new System.Drawing.Point(268, 55);
            this.btn_searchemployee.Name = "btn_searchemployee";
            this.btn_searchemployee.Size = new System.Drawing.Size(165, 41);
            this.btn_searchemployee.TabIndex = 3;
            this.btn_searchemployee.Text = "Search Employee";
            this.btn_searchemployee.UseVisualStyleBackColor = true;
            this.btn_searchemployee.Click += new System.EventHandler(this.btn_searchemployee_Click);
            // 
            // frm_employees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 391);
            this.Controls.Add(this.btn_searchemployee);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dg_employees);
            this.Controls.Add(this.btn_showemployee);
            this.Name = "frm_employees";
            this.Text = "frm_employees";
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_showemployee;
        private System.Windows.Forms.DataGridView dg_employees;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.Button btn_searchemployee;
    }
}