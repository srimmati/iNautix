﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace Win_ADO1
{
    public partial class frm_employees : Form
    {
        public frm_employees()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        private void btn_showemployee_Click(object sender, EventArgs e)
        {
            
            SqlDataAdapter data = new SqlDataAdapter("Select * from employees",con);
            DataSet ds = new DataSet();
            data.Fill(ds, "emp");
            dg_employees.DataSource=ds.Tables["emp"];
            
        }

        private void btn_searchemployee_Click(object sender, EventArgs e)
        {
            SqlDataAdapter data_employees = new SqlDataAdapter("select * from employees where employeecity=@city",con);
            data_employees.SelectCommand.Parameters.AddWithValue("@city",txt_city.Text);
            DataSet ds = new DataSet();
            data_employees.Fill(ds,"emp");
            if (ds.Tables["emp"].Rows.Count == 0)
            {
                MessageBox.Show("Employee Not Found");
            }
            else
            {
                dg_employees.DataSource=ds.Tables["emp"];
            }
        }
    }
}
