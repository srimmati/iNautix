﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_DBConnectAssignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        private void btn_Login_Click(object sender, EventArgs e)
        {
            SqlCommand com_login = new SqlCommand("select count(*) from employees where employeeid=@empid and employeepassword=@emppwd",con);
            
            com_login.Parameters.AddWithValue("@empid",txt_empid.Text);
            com_login.Parameters.AddWithValue("@emppwd",txt_password.Text);
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                MessageBox.Show("Valid User");
                frm_Customer obj = new frm_Customer();
                obj.Show();
            }
            else
            {
                MessageBox.Show("Invalid User");
            }
        }
    }
}
