﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_DBConnectAssignment
{
    public partial class frm_Customer : Form
    {
        public frm_Customer()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        private void frm_Customer_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_cities = new SqlCommand("select cityname from cities",con);
            SqlDataReader dr = com_cities.ExecuteReader();
            while (dr.Read())
            {
                cmb_city.Items.Add(dr.GetString(0));
            }
            con.Close();
        }

        private void btn_addCustomer_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_add_customer = new SqlCommand("insert customers values(@name,@city,@age,getdate())",con);
            com_add_customer.Parameters.AddWithValue("@name", txt_cname.Text);
            com_add_customer.Parameters.AddWithValue("@city",cmb_city.Text);
            com_add_customer.Parameters.AddWithValue("@age",txt_age.Text);
            com_add_customer.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Customer Added Successfully");
            txt_age.Clear();
            txt_cid.Clear();
            txt_cname.Clear();
            cmb_city.Text = "";

        }

      

        private void btn_findCustomer_Click_1(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_find = new SqlCommand("select * from customers where customerid=@custid", con);
            com_find.Parameters.AddWithValue("@custid", txt_cid.Text);
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                txt_cname.Text = dr.GetString(1);
                cmb_city.Text = dr.GetString(2);
                txt_age.Text = dr.GetInt32(3).ToString();
                txt_date.Text = dr.GetDateTime(4).ToString();

            }
            else
            {
                MessageBox.Show("Invalid Customer");
            }
            con.Close();
        }

    }
}
