﻿namespace Win_DBConnectAssignment
{
    partial class frm_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_cid = new System.Windows.Forms.Label();
            this.lbl_cname = new System.Windows.Forms.Label();
            this.lbl_ccity = new System.Windows.Forms.Label();
            this.lbl_cage = new System.Windows.Forms.Label();
            this.txt_cid = new System.Windows.Forms.TextBox();
            this.txt_cname = new System.Windows.Forms.TextBox();
            this.txt_age = new System.Windows.Forms.TextBox();
            this.cmb_city = new System.Windows.Forms.ComboBox();
            this.btn_addCustomer = new System.Windows.Forms.Button();
            this.btn_findCustomer = new System.Windows.Forms.Button();
            this.lbl_date = new System.Windows.Forms.Label();
            this.txt_date = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_cid
            // 
            this.lbl_cid.AutoSize = true;
            this.lbl_cid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cid.Location = new System.Drawing.Point(78, 53);
            this.lbl_cid.Name = "lbl_cid";
            this.lbl_cid.Size = new System.Drawing.Size(105, 20);
            this.lbl_cid.TabIndex = 0;
            this.lbl_cid.Text = "CustomerID";
            // 
            // lbl_cname
            // 
            this.lbl_cname.AutoSize = true;
            this.lbl_cname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cname.Location = new System.Drawing.Point(78, 96);
            this.lbl_cname.Name = "lbl_cname";
            this.lbl_cname.Size = new System.Drawing.Size(132, 20);
            this.lbl_cname.TabIndex = 0;
            this.lbl_cname.Text = "CustomerName";
            // 
            // lbl_ccity
            // 
            this.lbl_ccity.AutoSize = true;
            this.lbl_ccity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ccity.Location = new System.Drawing.Point(78, 146);
            this.lbl_ccity.Name = "lbl_ccity";
            this.lbl_ccity.Size = new System.Drawing.Size(116, 20);
            this.lbl_ccity.TabIndex = 0;
            this.lbl_ccity.Text = "CustomerCity";
            // 
            // lbl_cage
            // 
            this.lbl_cage.AutoSize = true;
            this.lbl_cage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cage.Location = new System.Drawing.Point(78, 202);
            this.lbl_cage.Name = "lbl_cage";
            this.lbl_cage.Size = new System.Drawing.Size(118, 20);
            this.lbl_cage.TabIndex = 0;
            this.lbl_cage.Text = "CustomerAge";
            // 
            // txt_cid
            // 
            this.txt_cid.Location = new System.Drawing.Point(240, 53);
            this.txt_cid.Name = "txt_cid";
            this.txt_cid.Size = new System.Drawing.Size(160, 20);
            this.txt_cid.TabIndex = 1;
            // 
            // txt_cname
            // 
            this.txt_cname.Location = new System.Drawing.Point(240, 93);
            this.txt_cname.Name = "txt_cname";
            this.txt_cname.Size = new System.Drawing.Size(160, 20);
            this.txt_cname.TabIndex = 1;
            // 
            // txt_age
            // 
            this.txt_age.Location = new System.Drawing.Point(240, 204);
            this.txt_age.Name = "txt_age";
            this.txt_age.Size = new System.Drawing.Size(160, 20);
            this.txt_age.TabIndex = 1;
            // 
            // cmb_city
            // 
            this.cmb_city.FormattingEnabled = true;
            this.cmb_city.Location = new System.Drawing.Point(240, 146);
            this.cmb_city.Name = "cmb_city";
            this.cmb_city.Size = new System.Drawing.Size(160, 21);
            this.cmb_city.TabIndex = 2;
            // 
            // btn_addCustomer
            // 
            this.btn_addCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addCustomer.Location = new System.Drawing.Point(118, 293);
            this.btn_addCustomer.Name = "btn_addCustomer";
            this.btn_addCustomer.Size = new System.Drawing.Size(159, 39);
            this.btn_addCustomer.TabIndex = 3;
            this.btn_addCustomer.Text = "Add Customer";
            this.btn_addCustomer.UseVisualStyleBackColor = true;
            this.btn_addCustomer.Click += new System.EventHandler(this.btn_addCustomer_Click);
            // 
            // btn_findCustomer
            // 
            this.btn_findCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_findCustomer.Location = new System.Drawing.Point(303, 293);
            this.btn_findCustomer.Name = "btn_findCustomer";
            this.btn_findCustomer.Size = new System.Drawing.Size(159, 39);
            this.btn_findCustomer.TabIndex = 3;
            this.btn_findCustomer.Text = "Find Customer";
            this.btn_findCustomer.UseVisualStyleBackColor = true;
            this.btn_findCustomer.Click += new System.EventHandler(this.btn_findCustomer_Click_1);
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.Location = new System.Drawing.Point(78, 247);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(134, 20);
            this.lbl_date.TabIndex = 0;
            this.lbl_date.Text = "Date Of Joining";
            // 
            // txt_date
            // 
            this.txt_date.Location = new System.Drawing.Point(240, 247);
            this.txt_date.Name = "txt_date";
            this.txt_date.Size = new System.Drawing.Size(160, 20);
            this.txt_date.TabIndex = 1;
            // 
            // frm_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 365);
            this.Controls.Add(this.btn_findCustomer);
            this.Controls.Add(this.btn_addCustomer);
            this.Controls.Add(this.cmb_city);
            this.Controls.Add(this.txt_date);
            this.Controls.Add(this.txt_age);
            this.Controls.Add(this.txt_cname);
            this.Controls.Add(this.txt_cid);
            this.Controls.Add(this.lbl_date);
            this.Controls.Add(this.lbl_cage);
            this.Controls.Add(this.lbl_ccity);
            this.Controls.Add(this.lbl_cname);
            this.Controls.Add(this.lbl_cid);
            this.Name = "frm_Customer";
            this.Text = "frm_Customer";
            this.Load += new System.EventHandler(this.frm_Customer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_cid;
        private System.Windows.Forms.Label lbl_cname;
        private System.Windows.Forms.Label lbl_ccity;
        private System.Windows.Forms.Label lbl_cage;
        private System.Windows.Forms.TextBox txt_cid;
        private System.Windows.Forms.TextBox txt_cname;
        private System.Windows.Forms.TextBox txt_age;
        private System.Windows.Forms.ComboBox cmb_city;
        private System.Windows.Forms.Button btn_addCustomer;
        private System.Windows.Forms.Button btn_findCustomer;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.TextBox txt_date;
    }
}