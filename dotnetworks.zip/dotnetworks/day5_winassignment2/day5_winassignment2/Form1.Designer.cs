﻿namespace day5_winassignment2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_days = new System.Windows.Forms.Label();
            this.lbl_salary = new System.Windows.Forms.Label();
            this.txt_days = new System.Windows.Forms.TextBox();
            this.txt_salary = new System.Windows.Forms.TextBox();
            this.btn_salarycalc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_days
            // 
            this.lbl_days.AutoSize = true;
            this.lbl_days.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_days.Location = new System.Drawing.Point(171, 120);
            this.lbl_days.Name = "lbl_days";
            this.lbl_days.Size = new System.Drawing.Size(98, 26);
            this.lbl_days.TabIndex = 0;
            this.lbl_days.Text = "No_Of_Days";
            // 
            // lbl_salary
            // 
            this.lbl_salary.AutoSize = true;
            this.lbl_salary.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_salary.Location = new System.Drawing.Point(174, 174);
            this.lbl_salary.Name = "lbl_salary";
            this.lbl_salary.Size = new System.Drawing.Size(130, 26);
            this.lbl_salary.TabIndex = 1;
            this.lbl_salary.Text = "Per_Day_Salary";
            // 
            // txt_days
            // 
            this.txt_days.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_days.Location = new System.Drawing.Point(331, 120);
            this.txt_days.Name = "txt_days";
            this.txt_days.Size = new System.Drawing.Size(100, 34);
            this.txt_days.TabIndex = 2;
            // 
            // txt_salary
            // 
            this.txt_salary.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_salary.Location = new System.Drawing.Point(331, 171);
            this.txt_salary.Name = "txt_salary";
            this.txt_salary.Size = new System.Drawing.Size(100, 34);
            this.txt_salary.TabIndex = 3;
            this.txt_salary.TextChanged += new System.EventHandler(this.txt_salary_TextChanged);
            // 
            // btn_salarycalc
            // 
            this.btn_salarycalc.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salarycalc.Location = new System.Drawing.Point(267, 239);
            this.btn_salarycalc.Name = "btn_salarycalc";
            this.btn_salarycalc.Size = new System.Drawing.Size(75, 31);
            this.btn_salarycalc.TabIndex = 4;
            this.btn_salarycalc.Text = "Salary Calc";
            this.btn_salarycalc.UseVisualStyleBackColor = true;
            this.btn_salarycalc.Click += new System.EventHandler(this.btn_salarycalc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 504);
            this.Controls.Add(this.btn_salarycalc);
            this.Controls.Add(this.txt_salary);
            this.Controls.Add(this.txt_days);
            this.Controls.Add(this.lbl_salary);
            this.Controls.Add(this.lbl_days);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_days;
        private System.Windows.Forms.Label lbl_salary;
        private System.Windows.Forms.TextBox txt_days;
        private System.Windows.Forms.TextBox txt_salary;
        private System.Windows.Forms.Button btn_salarycalc;
    }
}

