﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace day5_winassignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txt_salary_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_salarycalc_Click(object sender, EventArgs e)
        {
            int t1=Convert.ToInt32(txt_days.Text);
            int t2 = Convert.ToInt32(txt_salary.Text);
            day5_assignment2.Calcsal obj = new day5_assignment2.Calcsal();
            int sal=obj.calculate(t1, t2);
            MessageBox.Show("Your salary is:" + sal);
        }
    }
}
