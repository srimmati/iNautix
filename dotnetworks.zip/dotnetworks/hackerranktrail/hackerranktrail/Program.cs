﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace hackerranktrail
{
    class Program
    {
        static void Main(string[] args)
        {
          /*  string str = "dca";
           string[] array = { "abc", "bgdf", "utoio" };
           string str1 = string.Copy(str);
           Console.WriteLine("Copied string" + str1);
            char[] chararray = str.ToCharArray();


            
         
             for (int i = 0; i < array.Length; i++)
            {
                char[] chararray = array[i].ToCharArray();
                Array.Sort(chararray);
                foreach (char c in chararray)
                {
                    Console.Write(c);
                }
            } */



            string str = Console.ReadLine();
            char[] chararray = str.ToCharArray();
          /*  for (int i = 0; i < (chararray.Length-1); i++)
            {
                if (chararray[i] == chararray[i + 1])
                {
                    for (int j = i; j < (chararray.Length-1); j++)
                    {
                        chararray[j] = chararray[j + 1];
                    }
                }
               
            } */


            char[] chararray1 = chararray.Distinct().ToArray();

            foreach (char c in chararray1)
            {
                Console.Write(c);
            }

            Console.ReadLine();
        }
    }
}
