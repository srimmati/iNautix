﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_Assignment_company
{
    class Program
    {
        static void Main(string[] args)
        {
            Company comp = new Company(1001,"Inautix");
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1.ADD,2.REMOVE,3.FIND,4.SHOW,5.EXIT,6.Company approval");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        Console.WriteLine("enter id,name,city:");
                        int empid = Convert.ToInt32(Console.ReadLine());
                        string empname = Console.ReadLine();
                        string empcity = Console.ReadLine();
                        Employee obj = new Employee(empid, empname, empcity);
                        comp.AddEmployee(obj);
                        break;

                    case 2:
                        Console.WriteLine("Ënter empid:");
                        int emid = Convert.ToInt32(Console.ReadLine());
                        bool status = comp.RemoveEmployee(emid);
                        if (status == true)
                        {
                            Console.WriteLine("successfully removed");
                        }
                        else
                        {
                            Console.WriteLine("not found");
                        }
                        break;

                    case 3:
                        Console.WriteLine("enter emp id");
                        int eid = Convert.ToInt32(Console.ReadLine());
                        Employee emp = comp.SearchEmployee(eid);
                        if (emp == null)
                        {
                            Console.WriteLine("Employee not found");

                        }
                        else
                        {
                            Console.WriteLine("Ënter 1:show,2.Leave request:");
                            int option = Convert.ToInt32(Console.ReadLine());
                            if (option == 1)
                            {
                                Console.WriteLine(emp.ToString());
                            }
                            else
                            {
                                Console.WriteLine("Ener the reason:");
                                string reason = Console.ReadLine();
                                emp.request(reason);
                            }

                        }
                        break;
                    case 4:

                        comp.ShowEmployees();
                        break;
                    case 5:
                        flag = false;
                        break;
                    case 6:
                        comp.employee_leave_request_approval();
                        break;

                }
            }
        }
    }
}
