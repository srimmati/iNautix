﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_Assignment_company
{
    class Company
    {
        int CompanyID;
        string CompanyName;
        List<Employee> emplist = new List<Employee>();
        List<Employee> emplist_request = new List<Employee>();
        public Company(int CompanyID, string CompanyName)
        {
            this.CompanyID = CompanyID;
            this.CompanyName = CompanyName;
        }
        public void notify(int EmpID, string msg)
        {
            Console.WriteLine("Company:" + EmpID + " :" + msg);
            emplist_request.Add(SearchEmployee(EmpID));
        }
        public void employee_leave_request_approval()
        {
            foreach (Employee e in emplist_request)
            {
                e.Leave_approval();
            }
        }
        
        public void AddEmployee(Employee emp)
        {
            emplist.Add(emp);
            emp.evt_request += new Employee.delleave(notify);//bind
        }
        public bool RemoveEmployee(int EmpID)
        {
            foreach (Employee e in emplist)
            {
                if (e.PEmpID == EmpID)
                {
                    emplist.Remove(e);
                    return true;
                }
             }
            return false;
        }
        public Employee SearchEmployee(int EmpID)
        {
            foreach (Employee e in emplist)
            {
                if (e.PEmpID == EmpID)
                {
                    return e;
                }
            }
            return null;
        }
        public void ShowEmployees()
        {
            foreach (Employee e in emplist)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
}
