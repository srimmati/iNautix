﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_Assignment_company
{
    class Employee
    {
        public delegate void delleave(int EmpID,string msg);
        public  event delleave evt_request;
        public void request(string msg)
        {
            if(evt_request!=null)
            {
                evt_request(EmpID,msg);
            }
        }
        int EmpID;
        bool leave_status = false;
        public bool pstatus
        {
            get
            {
                return leave_status;
            }
        }
        public void Leave_approval()
        {
            leave_status = true;
        }
        public int PEmpID
        {
            get
            {
                return EmpID;
            }
        }

        string EmpName;
        string EmpCity;
        public Employee(int EmpID, string EmpName, string EmpCity)
        {
            this.EmpID = EmpID;
            this.EmpName = EmpName;
            this.EmpCity = EmpCity;
        }
        public override string ToString()
        {
            return EmpID + " " + EmpName + " " + EmpCity+" " +leave_status;
        }


    }
}
