﻿namespace service_demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_days = new System.Windows.Forms.TextBox();
            this.txt_perdaysal = new System.Windows.Forms.TextBox();
            this.btn_getsal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(128, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "No. Of Days";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(128, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Per Day Salary";
            // 
            // txt_days
            // 
            this.txt_days.Location = new System.Drawing.Point(270, 44);
            this.txt_days.Name = "txt_days";
            this.txt_days.Size = new System.Drawing.Size(100, 20);
            this.txt_days.TabIndex = 1;
            // 
            // txt_perdaysal
            // 
            this.txt_perdaysal.Location = new System.Drawing.Point(270, 152);
            this.txt_perdaysal.Name = "txt_perdaysal";
            this.txt_perdaysal.Size = new System.Drawing.Size(100, 20);
            this.txt_perdaysal.TabIndex = 1;
            // 
            // btn_getsal
            // 
            this.btn_getsal.Location = new System.Drawing.Point(149, 219);
            this.btn_getsal.Name = "btn_getsal";
            this.btn_getsal.Size = new System.Drawing.Size(196, 23);
            this.btn_getsal.TabIndex = 2;
            this.btn_getsal.Text = "GET SALARY";
            this.btn_getsal.UseVisualStyleBackColor = true;
            this.btn_getsal.Click += new System.EventHandler(this.btn_getsal_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(769, 514);
            this.Controls.Add(this.btn_getsal);
            this.Controls.Add(this.txt_perdaysal);
            this.Controls.Add(this.txt_days);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_days;
        private System.Windows.Forms.TextBox txt_perdaysal;
        private System.Windows.Forms.Button btn_getsal;
    }
}

