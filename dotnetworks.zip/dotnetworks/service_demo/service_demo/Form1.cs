﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace service_demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_getsal_Click(object sender, EventArgs e)
        {
            int days = Convert.ToInt32(txt_days.Text);
            int per_day_sal = Convert.ToInt32(txt_perdaysal.Text);


            localhost.WebService proxy = new localhost.WebService();


            int total = proxy.GetSalary(days, per_day_sal);


            MessageBox.Show("salary :" + total);

        }
    }
}
