﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day6_delegate
{
    class EventTesting
    {
        public delegate void delevt(string msg);
        public event delevt evt;
        public void fire()
        {
            if (evt != null)
            {
                evt("hello from event");
            }
        }
        //subscriber
        public void call(string str)
        {
            Console.WriteLine("Call:" + str);
        }
        public void bind()
        {
            delevt obj = new delevt(call);
            this.evt += obj;
        }
    }
}
