﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace win_wcfclient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_salary_Click(object sender, EventArgs e)
        {
            int days = Convert.ToInt32(txt_days.Text);
            int per_day_sal = Convert.ToInt32(txt_sal.Text);
            ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("BasicHttpBinding_IService");
            int salary = proxy.GetSalary(days, per_day_sal);
            proxy.Close();
            MessageBox.Show("Salary :" + salary);

        }
    }
}
