﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_GC
{
    class XYZ : IDisposable
    {
        public void Dispose()
        {
           //con.close , fs.close ...
            Console.WriteLine("Dispose");
        }
    }
}
