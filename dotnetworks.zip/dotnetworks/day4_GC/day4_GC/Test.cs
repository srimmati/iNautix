﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_GC
{
    class Test
    {
        public Test()
        {
            Console.WriteLine("object created");
        }
        ~Test()
        {
            Console.WriteLine("Destructor called");
        }
    }
}
