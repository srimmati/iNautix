﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_interface
{
    class ProductB :ITransport,ITesting 
    {
        public string id;
        public string name;
        public string addr;
        public string custname;
        public void run()
        {
        }
        public void stop()
        {
        }
        public string GetDetails()
        {
            return name + " " + addr;
        }

        public string GetCustomerAddress()
        {
            return name + " " + addr;
        }

        public bool Run()
        {
            this.run();
            return true;
        }

        public bool Stop()
        {
            this.stop();
            return true;
        }
    }
}
