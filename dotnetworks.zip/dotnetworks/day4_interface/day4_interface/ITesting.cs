﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_interface
{
    interface ITesting
    {
        bool Run();
        bool Stop();
    }
}
