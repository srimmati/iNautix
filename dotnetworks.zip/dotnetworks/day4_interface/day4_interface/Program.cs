﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_interface
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductA a = new ProductA();
            a.pid = "121";
            a.pname = "Mobile";
            a.customername = "abc";
            a.address = "chennai";

            ProductB b=new ProductB();
            b.id="120";
            b.name="laptop";
            b.custname="xyz";
            b.addr="madurai";

            Testing test = new Testing();
            bool statusa = test.RecProductForTesting(a);
            bool statusb = test.RecProductForTesting(b);


            Transport t=new Transport();
            if (statusa == true)
            {
                t.Rec_Product(a);
            }
            else
            {
                Console.WriteLine("ProductA is not OKAY!");
            }
            if (statusb == true)
            {
                t.Rec_Product(b);
            }
            else
            {
                Console.WriteLine("ProductB is not OKAY!");
            }
            Console.ReadLine();

           
        }
    }
}
