﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_interface
{
    class ProductA : ITransport, ITesting
    {
        public string pid;
        public string pname;
        public string address;
        public string customername;
        public void play()
         {
         }
        public void stop()
        {
        }
        public string GetAddress()
        {
            return pid + " " + pname + " " + address;
        }

        public string GetCustomerAddress()
        {
            return pid + " " + pname + " " + address;
        }

        public bool Run()
        {
            this.play();
            return true;
        }

        public bool Stop()
        {
            this.stop();
            return true;
        }
    }
}
