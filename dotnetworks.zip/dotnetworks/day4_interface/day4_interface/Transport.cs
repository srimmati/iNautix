﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4_interface
{
    class Transport
    {
        public void Rec_Product(ITransport obj)
        {
            string address = obj.GetCustomerAddress();
            Console.WriteLine(address);
        }
    }
}
