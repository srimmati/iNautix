﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>();
            list.Add(1);
            list.Add(35);
            list.Add(22);
            list.Add(35);
            Console.WriteLine(list.BinarySearch(35));

            HashSet<int> li = new HashSet<int>();
            li.Add(1);
            li.Add(35);
            li.Add(22);
            li.Add(35);
            list.
            foreach (int i in list)
            {
                Console.WriteLine(i);
            }
            ArrayList liss=new ArrayList();
            liss.Add(10);
            liss.Add("sri");

            SortedList<int,int> lis = new SortedList<int,int>();
            li.Add(1);
            li.Add(35);
            li.Add(22);
            li.Add(35);
            foreach (int i in list)
            {
                Console.WriteLine(i);
            } 

            string str = "hello";
            str= str.Insert(3,"sr");
            str=str.Substring(1, 2);
            Console.WriteLine(str);
            Console.ReadLine();




        }
    }
}
