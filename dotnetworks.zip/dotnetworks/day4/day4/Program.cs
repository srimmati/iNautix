﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day4
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
