﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_overriding
{
    class Employee_Contract : Employee
    {
        public Employee_Contract(int id, string name, int basic)
            : base(id, name, basic)
        {

        }
        public override int GetSalary()
        {
            return basic + 1000;
        }
    }
}
