﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_overriding
{
    class Employee
    {
        int id;
        string name;
        protected int basic;
        public Employee(int id, string name,int basic)
        {
            this.id = id;
            this.name = name;
            this.basic = basic;
        }
        public string GetWork()
        {
            return "Working as programmer";
        }
        public string GetDetails()
        {
            return id + " " + name;
        }
        public virtual int GetSalary()
        {
            int tax = 1200;
            return basic + tax;
        }

    }
}
