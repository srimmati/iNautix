﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter emp ID");
            int empid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter emp name");
            string empname = Console.ReadLine();
            Console.WriteLine("enter basic salary:");
            int basicsalary = Convert.ToInt32(Console.ReadLine());
            Employee obj;
            Console.WriteLine("Enter the type of employee:");
            string type = Console.ReadLine();
            if (type == "Employee")
            {
                obj = new Employee(empid, empname, basicsalary);
            }
            else if (type == "Employeecontract")
            {
                obj = new Employee_Contract(empid, empname, basicsalary);
            }
            else
            {
                obj = new Interns(empid, empname, basicsalary);
            }
         
            Console.WriteLine(obj.GetDetails());
            Console.WriteLine(obj.GetSalary());
            Console.WriteLine(obj.GetWork());
            Console.ReadLine();
        }
    }
}
