﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Runtime.Serialization.Json; //Add dll reference

namespace win_rest_client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_cal_Click(object sender, EventArgs e)
        {
            WebClient client_orders = new WebClient();
            string address = "http://localhost:50255/rest_wcf/Service.svc/myservice/FindOrder/"+textBox1.Text;
            client_orders.OpenReadCompleted += new OpenReadCompletedEventHandler(client_orders_OpenReadCompleted);
            client_orders.OpenReadAsync(new Uri(address, UriKind.Absolute));


        }

        void client_orders_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            DataContractJsonSerializer json = new DataContractJsonSerializer(typeof(Order));
            Order obj = json.ReadObject(e.Result) as Order;
            MessageBox.Show(obj.OrderId + " " + obj.OrderAmt);
        }

        private void btn_get_Click(object sender, EventArgs e)
        {
            WebClient client_getorders = new WebClient();
            string address = "http://localhost:50255/rest_wcf/Service.svc/myservice/GetOrders/" + txt_name.Text;
            client_getorders.OpenReadCompleted += new OpenReadCompletedEventHandler(client_getorders_OpenReadCompleted);
            client_getorders.OpenReadAsync(new Uri(address, UriKind.Absolute));
        }

        void client_getorders_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            DataContractJsonSerializer json = new DataContractJsonSerializer(typeof(List<Order>));
            List<Order> list = json.ReadObject(e.Result) as List<Order>;
            dg_orders.DataSource = list;
        }
    }
}
