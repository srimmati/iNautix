﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day5_assignment2
{
    public class Calcsal
    {
        int no_of_days, per_day_salary;
        public int calculate(int no_of_days, int per_day_salary)
        {
            return no_of_days * per_day_salary;
        }
    }
}
