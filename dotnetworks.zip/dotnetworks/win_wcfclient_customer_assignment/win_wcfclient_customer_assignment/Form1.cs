﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
namespace win_wcfclient_customer_assignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            try
            {
                ServiceReference1.Customer obj = new ServiceReference1.Customer();
                obj.CustomerName = txt_custname.Text;
                obj.CustomerCity = txt_custcity.Text;
                int custid = proxy.AddCustomer(obj);
                MessageBox.Show("customer Added :" + custid);
                txt_custid.Text = custid.ToString();
            }
            catch (FaultException<ServiceReference1.ErrorInfo> exp)
            {
                MessageBox.Show(exp.Detail.ErrorNo + " " + exp.Detail.ErrorDateTime + " " + exp.Detail.ErrorDetails);
                

            }
        }

        private void btn_get_Click(object sender, EventArgs e)
        {
            proxy.GetCustomersCompleted += new EventHandler<ServiceReference1.GetCustomersCompletedEventArgs>(proxy_GetCustomersCompleted);
            proxy.GetCustomersAsync(txt_search.Text);


        }

        void proxy_GetCustomersCompleted(object sender, ServiceReference1.GetCustomersCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                dg_cust.DataSource = e.Result.ToList();
            }
            else
            {
                MessageBox.Show(e.Error.Message);
            }
        }
    }
}
