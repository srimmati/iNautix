﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_assignment
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : Window
    {
        public Home()
        {
            InitializeComponent();
        }

        private void btn_calc_Click(object sender, RoutedEventArgs e)
        {
            Calculator obj1 = new Calculator();
            obj1.Show();
            this.Close();
        }

        private void btn_placeorder_Click(object sender, RoutedEventArgs e)
        {
            placeorder obj = new placeorder();
            obj.Show();
            this.Close();
        }
    }
}
