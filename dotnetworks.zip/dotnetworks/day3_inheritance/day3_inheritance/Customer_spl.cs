﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_inheritance
{
    class Customer_spl : Customer
    {
        string CustomerAddress;
        int CreditLimit;
        bool paymentstatus;
        public Customer_spl(int CustomerID, string CustomerName, string CustomerAddress, int CreditLimit)
            : base(CustomerID, CustomerName)
        {
            this.CustomerAddress = CustomerAddress;
            this.CreditLimit = CreditLimit;

        }
        public string GetAddress()
        {
            return CustomerAddress;
        }

    }
}
