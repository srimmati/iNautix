﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_inheritance
{
    class Customer
    {
        int CustomerID;
        string CustomerName;
        public Customer(int CustomerID, string CustomerName)
        {
            this.CustomerID = CustomerID;
            this.CustomerName = CustomerName;
        }
        public Customer(int CustomerID)
        {
            this.CustomerID = CustomerID;
            this.CustomerName = "Sripavi"; //Database
        }
        public string GetDetails()
        {
            return CustomerID+" "+CustomerName;
        }
    }

}
