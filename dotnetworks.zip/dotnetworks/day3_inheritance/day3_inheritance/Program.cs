﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day3_inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Customer Id:");
            int custid=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name:");
            string custname=Console.ReadLine();
            Console.WriteLine("Enter type of customer");
            string type = Console.ReadLine();
            if (type == "Customer")
            {
                Customer obj = new Customer(custid, custname);
                string details = obj.GetDetails();
                Console.WriteLine(details);
            }
            else
            {
                Console.WriteLine("Enter Address");
                string address = Console.ReadLine();
                Customer_spl obj = new Customer_spl(custid, custname, address, 1000);
                string details = obj.GetDetails();
                Console.WriteLine(details);
                string add = obj.GetAddress();
                Console.WriteLine(add);
            }
            Console.ReadLine();
        }
    }
}
