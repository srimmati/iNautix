﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day2_assignment
{
    class Program
    {
        static void Main(string[] args)
        {
      
            bool wantorder = true;
            Console.WriteLine("Number of Orders placed : :" + Order.TotalOrder);
                do
                {
                    
                    Console.WriteLine("Enter the itemID:");
                    int iid = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the itemQuantity:");
                    int iqty = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the itemPrice:");
                    int iprice = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the customerName:");
                    string cname = Console.ReadLine();
                    Order obj = new Order(iid, iqty, iprice, cname);
                    
            
                    Console.WriteLine("OrderId :"+obj.porderid);
                    Console.WriteLine("OrderValue :"+obj.pordervalue);
            
                    Console.WriteLine("Do you want to enter the orders again 1.YES 2.NO");
                    int ch = Convert.ToInt32(Console.ReadLine());
                    switch (ch)
                    {
                        case 1:
                            wantorder = true;
                            break;
                        case 2:
                            wantorder = false;
                            break;
                    }

                } while (wantorder);

                Console.WriteLine("Number of Orders placed : :" + Order.TotalOrder);
        }
    }
}
