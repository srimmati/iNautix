﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace day2_assignment
{
    class Order
    {
        
       static int count;
       public static int TotalOrder
       {
           get
           {
               return count;
           }
       }

       public Order(int iid, int iqty, int iprice, string cname)
       {
           count++;
           this.iid = iid;
           this.iqty = iqty;
           this.iprice = iprice;
           this.cname = cname;
           this.oid = count;
       }
        int iid;
        int iqty;
        int iprice;
        int oid;
        
        string cname;
       
        public int porderid
        {
            get
            {
                return oid; 
            }
         
        }
        public int pordervalue
        {
            get
            {
                return iqty * iprice;
            }
        
        }
        
    }
}
