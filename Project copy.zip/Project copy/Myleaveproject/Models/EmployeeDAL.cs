﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Configuration;
using System.Data.SqlClient;

namespace Myleaveproject.Models
{
    public class EmployeeDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public bool NewEmployees(newemployeedetail add, string password, string email, string securityques, string securityans)
        {
            con.Open();

            SqlCommand com_add = new SqlCommand("insert newemployeedetails values(@mid,@fname,@lname,@contact,@dob,@deprt,@exp,@datehired,@pan,@adhar,null,@sal,@unpaid,@paid)", con);

            com_add.Parameters.AddWithValue("@mid", add.ManagerId);
            com_add.Parameters.AddWithValue("@fname", add.FirstName);
            com_add.Parameters.AddWithValue("@lname", add.LastName);
            com_add.Parameters.AddWithValue("@contact", add.EmployeeContact);
            com_add.Parameters.AddWithValue("@dob", add.EmployeeDOB);
            com_add.Parameters.AddWithValue("@deprt", add.Department);
            com_add.Parameters.AddWithValue("@exp", add.EmployeeExperience);
            com_add.Parameters.AddWithValue("@datehired", add.DateHired);
            com_add.Parameters.AddWithValue("@pan", add.PanId);
            com_add.Parameters.AddWithValue("@adhar", add.AdharId);
            com_add.Parameters.AddWithValue("@sal", add.EmployeeSalary);
            com_add.Parameters.AddWithValue("@unpaid", add.NoOfUnpaidLeaves);
            com_add.Parameters.AddWithValue("@paid", add.NoOfPaidLeaves);
            com_add.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);

            int empid = Convert.ToInt32(com_id.ExecuteScalar());
            add.EmployeeId = empid;
            add.EmployeeImgAddress = "/Images/" + empid + ".jpg";

            SqlCommand com_product_image_address = new SqlCommand("update newemployeedetails set EmployeeImgAddress=@address where EmployeeId=@eid", con);
            com_product_image_address.Parameters.AddWithValue("@eid", add.EmployeeId);
            com_product_image_address.Parameters.AddWithValue("@address", add.EmployeeImgAddress);
            com_product_image_address.ExecuteNonQuery();
            con.Close();

            MembershipCreateStatus status;
            Membership.CreateUser(add.EmployeeId.ToString(), password, email, securityques, securityans, true, out status);
            if (status == MembershipCreateStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public newemployeedetail Emphome(int EmployeeId)
        {

            SqlCommand com_orders = new SqlCommand("select * from newemployeedetails where EmployeeId=@eid", con);
            com_orders.Parameters.AddWithValue("@eid", EmployeeId);
            con.Open();

            SqlDataReader dr = com_orders.ExecuteReader();
            newemployeedetail p = new newemployeedetail();
            while (dr.Read())
            {

                p.EmployeeId = dr.GetInt32(0);
                p.FirstName = dr.GetString(2);
                p.LastName = dr.GetString(3);
                p.EmployeeContact = dr.GetString(4);
                p.EmployeeDOB = dr.GetDateTime(5);
                p.Department = dr.GetString(6);
                p.EmployeeImgAddress = dr.GetString(11);


            }

            con.Close();
            return p;


        }
        public newemployeedetail LeaveBal(int EmployeeId)
        {
            SqlCommand com_orders = new SqlCommand("select * from newemployeedetails where EmployeeId=@eid", con);
            com_orders.Parameters.AddWithValue("@eid", EmployeeId);
            con.Open();
            SqlDataReader dr = com_orders.ExecuteReader();
            newemployeedetail p = new newemployeedetail();
            while (dr.Read())
            {
                p.NoOfUnpaidLeaves = dr.GetInt32(13);
                p.NoOfPaidLeaves = dr.GetInt32(14);
            }
            con.Close();
            return p;

        }
        public int pendingleave(int EmployeeId)
        {
            SqlCommand pending = new SqlCommand("select count(*) from newleavetable1 where LeaveStatus='pending' and EmployeeId=@eid", con);
            pending.Parameters.AddWithValue("@eid", EmployeeId);
            con.Open();
            int count = Convert.ToInt32(pending.ExecuteScalar());
            con.Close();
            return count;
        }
        public int approvedleave(int EmployeeId)
        {
            SqlCommand pending = new SqlCommand("select count(*) from newleavetable1 where LeaveStatus='Approved' and EmployeeId=@eid", con);
            pending.Parameters.AddWithValue("@eid", EmployeeId);
            con.Open();
            int count = Convert.ToInt32(pending.ExecuteScalar());
            con.Close();
            return count;
        }
        public int Getid(int EmployeeId)
        {
            SqlCommand com_mid = new SqlCommand("select ManagerId from newemployeedetails where EmployeeId=@eid", con);
            com_mid.Parameters.AddWithValue("@eid", EmployeeId);
            con.Open();
            int mid = Convert.ToInt32(com_mid.ExecuteScalar());
            con.Close();
            return mid;
        }
        public newemployeedetail Managerhome(int EmployeeId)
        {

            SqlCommand com_orders = new SqlCommand("select * from newemployeedetails where EmployeeId=@eid", con);
            com_orders.Parameters.AddWithValue("@eid", EmployeeId);
            con.Open();

            SqlDataReader dr = com_orders.ExecuteReader();
            newemployeedetail p = new newemployeedetail();
            while (dr.Read())
            {

                p.EmployeeId = dr.GetInt32(0);
                p.FirstName = dr.GetString(2);
                p.LastName = dr.GetString(3);
                p.EmployeeContact = dr.GetString(4);
                p.EmployeeDOB = dr.GetDateTime(5);
                p.Department = dr.GetString(6);
                p.EmployeeImgAddress = dr.GetString(11);


            }

            con.Close();
            return p;
        }
    }
}