﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

namespace Myleaveproject.Models
{
    public class LeaveDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public bool ApplyLeave(Leave l)
        {
 
            SqlCommand com_insert = new SqlCommand("insert newleavetable1 values(@empid,@startdate,@noofdays,@reason,'pending')", con);
            com_insert.Parameters.AddWithValue("@empid", l.EmployeeId);
            com_insert.Parameters.AddWithValue("@startdate", l.StartDate);
            com_insert.Parameters.AddWithValue("@noofdays", l.NoOfDays);
            com_insert.Parameters.AddWithValue("@reason", l.Reason);
            
          
            
            con.Open();
            com_insert.ExecuteNonQuery();
            return true;
        }

        public List<Leave> ShowStatus(int EmployeeId)
        {
            List<Leave> emp_list = new List<Leave>();
            SqlCommand com_get = new SqlCommand("select * from newleavetable1 where LeaveStatus='pending' and EmployeeId=@empid", con);
            com_get.Parameters.AddWithValue("@empid", EmployeeId);
            con.Open();
            SqlDataReader dr = com_get.ExecuteReader();
            while(dr.Read())
            {
                Leave c = new Leave();
                c.EmployeeId = dr.GetInt32(0);
                c.StartDate = dr.GetDateTime(1);
                c.NoOfDays = dr.GetInt32(2);
                c.Reason = dr.GetString(3);
                c.LeaveStatus = dr.GetString(4);
                emp_list.Add(c);
            }
            con.Close();
            return emp_list;



        }
        public List<Leave> ShowApproved(int EmployeeId)
        {
            List<Leave> emp_list = new List<Leave>();
            SqlCommand com_get = new SqlCommand("select * from newleavetable1 where LeaveStatus='Approved' and EmployeeId=@empid", con);
            com_get.Parameters.AddWithValue("@empid", EmployeeId);
            con.Open();
            SqlDataReader dr = com_get.ExecuteReader();
            while (dr.Read())
            {
                Leave c = new Leave();
                c.EmployeeId = dr.GetInt32(0);
                c.StartDate = dr.GetDateTime(1);
                c.NoOfDays = dr.GetInt32(2);
                c.Reason = dr.GetString(3);
                c.LeaveStatus = dr.GetString(4);
                emp_list.Add(c);
            }
            con.Close();
            return emp_list;



        }

        public bool Withdraw(int id, DateTime date)
        {
            SqlCommand com_update = new SqlCommand("update newleavetable1 set LeaveStatus='Cancel' where EmployeeId=@eid and StartDate=@date", con);
          
            com_update.Parameters.AddWithValue("@eid", id);
            com_update.Parameters.AddWithValue("@date",date);
            con.Open();
            com_update.ExecuteNonQuery();
            con.Close();
            return true;
        }

        public bool WithdrawApproved(int id, DateTime date)
        {
            SqlCommand com_update = new SqlCommand("update newleavetable1 set LeaveStatus='Cancel' where EmployeeId=@eid and StartDate=@date", con);

            com_update.Parameters.AddWithValue("@eid", id);
            com_update.Parameters.AddWithValue("@date", date);
            con.Open();
            com_update.ExecuteNonQuery();

            SqlCommand com_insert = new SqlCommand("insert cancelapproved values(@empid,@startdate,'Cancel')", con);
            com_insert.Parameters.AddWithValue("@empid", id);
            com_insert.Parameters.AddWithValue("@startdate", date);
   
            com_insert.ExecuteNonQuery();
            con.Close();
            return true;
        }









        public List<Leave> Approve(int EmployeeId)
        {
            List<Leave> emp_list = new List<Leave>();
            SqlCommand com_get = new SqlCommand("select * from newleavetable1 where LeaveStatus='pending' and EmployeeId in (select EmployeeId from newemployeedetails where ManagerId=@empid)", con);
            com_get.Parameters.AddWithValue("@empid", EmployeeId);
            con.Open();
            SqlDataReader dr = com_get.ExecuteReader();
            while (dr.Read())
            {
                Leave c = new Leave();
                c.EmployeeId = dr.GetInt32(0);
                c.StartDate = dr.GetDateTime(1);
                c.NoOfDays = dr.GetInt32(2);
                c.Reason = dr.GetString(3);
                c.LeaveStatus = dr.GetString(4);
                emp_list.Add(c);
            }
            con.Close();
            return emp_list;
        }

          public bool ApproveLeave(int id, DateTime date)
           {
            SqlCommand com_update = new SqlCommand("update newleavetable1 set LeaveStatus='Approved' where EmployeeId=@eid and StartDate=@date", con);
          
            com_update.Parameters.AddWithValue("@eid", id);
            com_update.Parameters.AddWithValue("@date",date);
            con.Open();
            com_update.ExecuteNonQuery();
            con.Close();
            return true;
        }

          public bool ApplyLeaveMan(Leave l)
          {

              SqlCommand com_insert = new SqlCommand("insert newleavetable1 values(@empid,@startdate,@noofdays,@reason,'Approved')", con);
              com_insert.Parameters.AddWithValue("@empid", l.EmployeeId);
              com_insert.Parameters.AddWithValue("@startdate", l.StartDate);
              com_insert.Parameters.AddWithValue("@noofdays", l.NoOfDays);
              com_insert.Parameters.AddWithValue("@reason", l.Reason);

      
              con.Open();
              com_insert.ExecuteNonQuery();
              return true;
          }
          public List<Leave> ShowApprovedMan(int EmployeeId)
          {
              List<Leave> emp_list = new List<Leave>();
              SqlCommand com_get = new SqlCommand("select * from newleavetable1 where LeaveStatus='Approved' and EmployeeId=@empid", con);
              com_get.Parameters.AddWithValue("@empid", EmployeeId);
              con.Open();
              SqlDataReader dr = com_get.ExecuteReader();
              while (dr.Read())
              {
                  Leave c = new Leave();
                  c.EmployeeId = dr.GetInt32(0);
                  c.StartDate = dr.GetDateTime(1);
                  c.NoOfDays = dr.GetInt32(2);
                  c.Reason = dr.GetString(3);
                  c.LeaveStatus = dr.GetString(4);
                  emp_list.Add(c);
              }
              con.Close();
              return emp_list;



          }
          public bool WithdrawApprovedMan(int id, DateTime date)
          {
              SqlCommand com_update = new SqlCommand("update newleavetable1 set LeaveStatus='Cancel' where EmployeeId=@eid and StartDate=@date", con);

              com_update.Parameters.AddWithValue("@eid", id);
              com_update.Parameters.AddWithValue("@date", date);
              con.Open();
              com_update.ExecuteNonQuery();

              SqlCommand com_insert = new SqlCommand("insert cancelapproved values(@empid,@startdate,'Cancel')", con);
              com_insert.Parameters.AddWithValue("@empid", id);
              com_insert.Parameters.AddWithValue("@startdate", date);

              com_insert.ExecuteNonQuery();
              con.Close();
              return true;
          }


     }
    
}
