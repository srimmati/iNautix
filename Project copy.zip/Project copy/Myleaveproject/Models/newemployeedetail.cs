﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Myleaveproject.Models
{
    public class newemployeedetail
    {
        [Display(Name="Employee Id")]
        public int EmployeeId { get; set; }

        [Display(Name = "Manager Id")]
        public Nullable<int> ManagerId { get; set; }

        [Display(Name = "First Name")]
        [Required]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        [Required]
        public string LastName { get; set; }

        [Display(Name = "Contact")]
        [Required]
        public string EmployeeContact { get; set; }

        [Display(Name = "Date of Birth")]
        [Required]
        public Nullable<System.DateTime> EmployeeDOB { get; set; }

        [Display(Name = "Department")]
        [Required]
        public string Department { get; set; }

        [Display(Name = "Experience")]
        [Required]
        public Nullable<int> EmployeeExperience { get; set; }

        [Display(Name = "Date Hired")]
        [Required]
        public Nullable<System.DateTime> DateHired { get; set; }

        [Display(Name = "PAN ID")]
        [Required]
        public string PanId { get; set; }

        [Display(Name = "Adhar ID")]
        [Required]
        public string AdharId { get; set; }

        [Display(Name = "Image")]
        [Required]
        public string EmployeeImgAddress { get; set; }

        [Display(Name = "Salary")]
        [Required]
        public Nullable<int> EmployeeSalary { get; set; }

        [Display(Name = "No of Unpaid Leave")]
        [Required]
        public Nullable<int> NoOfUnpaidLeaves { get; set; }

        [Display(Name = "No of paid Leave")]
        [Required]
        public Nullable<int> NoOfPaidLeaves { get; set; }

        [Display(Name = "Email")]
        [Required]
        public string Email { get; set; }

        [Display(Name = "Password")]
        [Required]
        public string Password { get; set; }

        [Display(Name = "Security Question")]
        [Required]
        public string SecurityQuestion { get; set; }


        [Display(Name = "Security Answer")]
        [Required]
        public string SecurityAnswer { get; set; }

    }
}