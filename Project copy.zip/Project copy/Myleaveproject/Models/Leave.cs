﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Myleaveproject.Models
{
    public class Leave
    {
        [Display(Name = "Employee Id")]
        public int EmployeeId { get; set; }



        [Display(Name = "Start Date")]
        [Required]
        public Nullable<System.DateTime> StartDate { get; set; }

        [Display(Name = "No of Days")]
        [Required]
        public Nullable<int> NoOfDays { get; set; }

        [Display(Name = "Reason")]
        [Required]
        public string Reason { get; set; }

        [Display(Name = "Leave Status")]
        [Required]
        public string LeaveStatus { get; set; }






    }
}