﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Myleaveproject.Models;
using System.Web.Security;

namespace Myleaveproject.Controllers
{
    public class ManagerController : Controller
    {
        //
        // GET: /Manager/

        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult Managerhome()
        {
            int EmployeeId = Convert.ToInt32(User.Identity.Name);
            EmployeeDAL dal = new EmployeeDAL();
            newemployeedetail emp = dal.Emphome(EmployeeId);
            return View(emp);
        }
        [Authorize]
        public ActionResult Approve()
        {
            return View();
        }
        [HttpPost]
        [Authorize]
        public ActionResult Approve(int EmployeeId)
        {
            LeaveDAL dal = new LeaveDAL();
            List<Leave> emplist = dal.Approve(EmployeeId);
            return PartialView("approvepartialview", emplist);
        }
        [Authorize]
        public ActionResult ApproveLeave(int id, DateTime date)
        {

            LeaveDAL dal = new LeaveDAL();
            bool status = dal.ApproveLeave(id, date);
            if (status)
            {
                return View("Approved");
            }
            else
            {
                return View("Notapproved");
            }

        }
        [Authorize]
        public ActionResult LeaveBalMan()
        {
            int EmployeeId = Convert.ToInt32(User.Identity.Name);
            EmployeeDAL dal = new EmployeeDAL();
            newemployeedetail emp = dal.LeaveBal(EmployeeId);
            int pending = dal.pendingleave(EmployeeId);
            ViewBag.pending = pending;

            int approved = dal.approvedleave(EmployeeId);
            ViewBag.approved = approved;
            return View(emp);
        }
        [AllowAnonymous]
        public ActionResult ApplyLeaveMan()
        {
            return View();
        }
        [HttpPost]
        [Authorize]
        public ActionResult ApplyLeaveMan(Leave model)
        {
            model.EmployeeId = Convert.ToInt32(User.Identity.Name);
            LeaveDAL dal = new LeaveDAL();
            bool status = dal.ApplyLeaveMan(model);
            ViewBag.msg = "Leave Applied";
            ViewBag.eid = model.EmployeeId;
            return View();
        }
        [Authorize]
        public ActionResult ShowApprovedMan()
        {
            int EmployeeId = Convert.ToInt32(User.Identity.Name);
            LeaveDAL dal = new LeaveDAL();
            List<Leave> emplist = dal.ShowApproved(EmployeeId);
            return View("ShowApprovedMan", emplist);


        }
        [Authorize]
        public ActionResult WithdrawApprovedMan(int id, DateTime date)
        {

            LeaveDAL dal = new LeaveDAL();
            bool status = dal.WithdrawApprovedMan(id, date);
            if (status)
            {
                return View("SuccessMan");
            }
            else
            {
                return View("NotsuccessMan");
            }

        }
        [Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Home");
        }
     
    }
}
