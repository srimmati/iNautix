﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Myleaveproject.Models;

namespace Myleaveproject.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

      
        [Authorize]

        public ActionResult Emphome()
        {
            int EmployeeId = Convert.ToInt32(User.Identity.Name);
            EmployeeDAL dal = new EmployeeDAL();
            newemployeedetail emp = dal.Emphome(EmployeeId);
            return View(emp);
        }
        

        [AllowAnonymous]
        public ActionResult NewEmployees()
        {
            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult NewEmployees(newemployeedetail model, HttpPostedFileBase Filedata)
        {


            EmployeeDAL dal = new EmployeeDAL ();
            bool status = dal.NewEmployees(model,model.Password,model.Email,model.SecurityQuestion,model.SecurityAnswer);
            ViewBag.msg = "Employee Added";
            ViewBag.eid = model.EmployeeId;
            Filedata.SaveAs(Server.MapPath(model.EmployeeImgAddress));
            return View();

        }
        [AllowAnonymous]
        public ActionResult Login()
        {
            
            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult Login(int EmployeeId, string Password, bool rememberme)
        {
            if (Membership.ValidateUser(EmployeeId.ToString(), Password))
            {
               
                newemployeedetail emp=new newemployeedetail();
                FormsAuthentication.SetAuthCookie(EmployeeId.ToString(), rememberme);
                EmployeeDAL dal=new EmployeeDAL();
                int managerid = dal.Getid(EmployeeId);
                if(managerid==0)
                {
                    return RedirectToAction("Managerhome", "Manager");
                }
                else
                {


                    return RedirectToAction("Emphome","Home");
                }
                
            }
            else
            {
                ViewBag.msg = "Invalid ID and Password";
                return View();
            }
        }
        [Authorize]
        public ActionResult LeaveBal()
        {
            int EmployeeId = Convert.ToInt32(User.Identity.Name);
            EmployeeDAL dal = new EmployeeDAL();
            newemployeedetail emp = dal.LeaveBal(EmployeeId);
            int pending = dal.pendingleave(EmployeeId);
            ViewBag.pending = pending;
      
            int approved = dal.approvedleave(EmployeeId);
            ViewBag.approved = approved;
            return View(emp);
        }
        
        [AllowAnonymous]
        public ActionResult ApplyLeave()
        {
            return View();
        }
        [HttpPost]
        [Authorize]
        public ActionResult ApplyLeave(Leave model)
        {
            model.EmployeeId = Convert.ToInt32(User.Identity.Name);
            LeaveDAL dal = new LeaveDAL();
            bool status = dal.ApplyLeave(model);
            ViewBag.msg = "Leave Requested";
            ViewBag.eid = model.EmployeeId;
            return View();
        }
        [Authorize]
        public ActionResult ShowStatus()
    
        {
            int EmployeeId = Convert.ToInt32(User.Identity.Name);
            LeaveDAL dal = new LeaveDAL();
            List<Leave> emplist = dal.ShowStatus(EmployeeId);
            return View("ShowStatus",emplist);
           

        }
        [Authorize]
        public ActionResult ShowApproved()
        {
            int EmployeeId = Convert.ToInt32(User.Identity.Name);
            LeaveDAL dal = new LeaveDAL();
            List<Leave> emplist = dal.ShowApproved(EmployeeId);
            return View("ShowApproved", emplist);


        }

        [Authorize]
        public ActionResult Withdraw(int id,DateTime date)
        {

            LeaveDAL dal = new LeaveDAL();
            bool status = dal.Withdraw(id, date);
            if(status)
            {
                return View("Success");
            }
            else
            {
                return View("Notsuccess");
            }

        }
        [Authorize]
        public ActionResult WithdrawApproved(int id, DateTime date)
        {

            LeaveDAL dal = new LeaveDAL();
            bool status = dal.WithdrawApproved(id, date);
            if (status)
            {
                return View("Success");
            }
            else
            {
                return View("Notsuccess");
            }

        }
        [Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Home");
        }
          

    }
    
}
